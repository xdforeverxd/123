extends SceneTree

var passed := 0
var failed := 0

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	if condition:
		passed += 1
		print("PASS: ",description)
	else:
		failed += 1
		push_error("FAIL: "+description)

func run() -> void:
	print("Android landscape enum = ",DisplayServer.SCREEN_SENSOR_LANDSCAPE)
	var s := AetheriaState.new()
	check(not s.claim(0),"unfinished quest cannot be claimed")
	s.visited = true
	check(s.claim(0) and s.gold==25,"completed quest grants reward")
	check(not s.claim(0) and s.gold==25,"quest cannot be claimed twice")
	check(not s.craft(),"crafting requires materials")
	s.wood = 15
	s.ore = 9
	check(s.craft() and s.weapon==2 and s.wood==10 and s.ore==6,"crafting consumes exact materials")
	check(s.craft() and not s.craft() and s.weapon==3,"weapon upgrade cap preserves materials")
	s = AetheriaState.new()
	s.hp = 1
	check(s.add_xp(350) and s.level==3 and s.xp==50 and s.hp==140,"multiple level ups restore health and preserve XP remainder")
	s.position = Vector2(5.9,13)
	s.move(Vector2.RIGHT,0.1)
	check(s.position.x<6,"water blocks movement")
	check(not AetheriaState.walkable(Vector2(-1,20)),"world boundary blocks movement")
	s.apply_data({"x":10,"y":13,"hp":9999,"level":0,"weapon":50,"mana":999,"gold":"bad","visited":"bad","rewarded":[0,0,99,"bad"]})
	check(s.level==1 and s.weapon==3 and s.hp==100 and s.mana==60,"invalid save values are clamped")
	check(s.rewarded==[0] and not s.visited,"invalid and duplicate save reward entries are rejected")
	s.position = Vector2(19,21)
	s.wood = 7
	check(s.save_game(),"native save written atomically")
	var loaded := AetheriaState.new()
	check(loaded.load_game() and loaded.wood==7 and loaded.position==s.position,"native save round trip")
	var game: Node = load("res://scripts/main.gd").new()
	root.add_child(game)
	await process_frame
	game.set_process(false)
	game.sound_on = false
	game.state = AetheriaState.new()
	check(game.enemies.size()==6 and game.resources.size()>30,"village, forest and guardian initialized")
	check(game.world.unproject(game.world.project(Vector2(25,22))).distance_to(Vector2(25,22))<0.001,"isometric tap projection round trip")
	game.state.position = game.npc_position
	game.action("interact")
	check(game.state.visited,"native interaction completes Mira objective")
	game.state.wood = 3
	game.sell_wood()
	check(game.state.wood==0 and game.state.gold==12,"native merchant trade consumes wood and grants gold")
	game.state.position = game.resources[0].position
	game.action("interact")
	check(game.state.gathered==1 and game.state.wood+game.state.ore==1,"resource collection updates inventory and quest")
	var enemy: Dictionary = game.enemies[0]
	game.state.position = enemy.position
	game.action("attack")
	check(enemy.hp==enemy.max_hp-game.state.attack_damage(),"native melee attack applies damage")
	var old_hp: float = enemy.hp
	game.action("attack")
	check(enemy.hp==old_hp,"attack cooldown blocks duplicate damage")
	game.cooldowns.attack = 0
	game.action("attack")
	game.cooldowns.attack = 0
	game.action("attack")
	check(enemy.hp==0 and game.state.kills==1 and game.state.gold>=20,"enemy death grants loot and kill progress")
	game.state.hp = 30
	game.state.mana = 60
	game.action("heal")
	check(game.state.hp==75 and game.state.mana==40,"healing consumes mana and restores health")
	game.action("dash")
	check(game.dash_left>0 and game.cooldowns.dash==3,"dodge has invulnerability window and cooldown")
	var boss: Dictionary = game.enemies[-1]
	game.state.position = boss.position
	boss.windup = 0.01
	boss.aim = game.state.position
	var before: float = game.state.hp
	game.update_enemies(0.02)
	check(game.state.hp==before,"dodge avoids telegraphed boss damage")
	game.dash_left = 0
	boss.windup = 0.01
	boss.aim = game.state.position
	game.update_enemies(0.02)
	check(game.state.hp==before-24,"telegraphed boss strike deals damage when not dodged")
	game.damage_enemy(boss,9999)
	check(game.state.boss_defeated and boss.hp==0,"boss defeat completes final objective")
	game.hud.show_modal("inventory")
	var old_clock: float = game.clock
	game._process(0.05)
	check(game.clock==old_clock,"menus pause combat simulation")
	game.hud.close_modal()
	var touch := InputEventScreenTouch.new()
	touch.pressed = true
	touch.index = 0
	touch.position = game.hud.joystick_center+Vector2(35,0)
	game._input(touch)
	check(game.stick.x>0.8,"native touch starts movement joystick")
	var second_touch := InputEventScreenTouch.new()
	second_touch.pressed = true
	second_touch.index = 1
	second_touch.position = game.hud.skill_buttons.dash.get_global_rect().get_center()
	game.cooldowns.dash = 0.0
	game._input(second_touch)
	check(game.dash_left>0 and game.stick.x>0.8,"second finger can dodge while first finger holds joystick")
	touch.pressed = false
	game._input(touch)
	check(game.stick==Vector2.ZERO,"touch release stops joystick")
	var bounds := Rect2(Vector2.ZERO,game.hud.size)
	for action in game.hud.skill_buttons:
		var b: Button = game.hud.skill_buttons[action]
		check(bounds.encloses(b.get_rect()),"landscape skill fits viewport: "+action)
	for dimensions in [Vector2i(852,393),Vector2i(640,360),Vector2i(568,320)]:
		root.size = dimensions
		await process_frame
		await process_frame
		var viewport_bounds := Rect2(Vector2.ZERO,game.hud.size)
		var fits := true
		for action in game.hud.skill_buttons:
			var b: Button = game.hud.skill_buttons[action]
			fits = fits and viewport_bounds.encloses(b.get_rect())
		check(fits,"native HUD fits landscape resolution: %s" % dimensions)
		game.hud.show_modal("inventory")
		var modal_panel: Control = game.hud.modal.get_child(1)
		check(viewport_bounds.encloses(modal_panel.get_global_rect()),"inventory fits landscape resolution: %s" % dimensions)
		game.hud.close_modal()
	game.queue_free()
	await process_frame
	print("RESULT: %d passed, %d failed" % [passed,failed])
	quit(1 if failed else 0)
