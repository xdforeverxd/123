extends SceneTree

func _initialize() -> void:
	call_deferred("capture")

func capture() -> void:
	var game: Node = load("res://scripts/main.gd").new()
	root.add_child(game)
	game.state = AetheriaState.new()
	game.hud.toast_left = 0
	for i in 5:
		await process_frame
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	image.save_png("/tmp/aetheria-godot-native.png")
	game.hud.show_modal("inventory")
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/aetheria-godot-inventory.png")
	print("NATIVE_RENDER_OK: ",image.get_size())
	game.queue_free()
	await process_frame
	quit()
