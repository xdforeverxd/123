extends Node2D

var state := AetheriaState.new()
var world: AetheriaWorld
var hud: AetheriaHUD
var clock := 0.0
var stick := Vector2.ZERO
var destination := Vector2.ZERO
var has_destination := false
var walking := false
var last_direction := Vector2(1,0)
var dash_left := 0.0
var dash_direction := Vector2.ZERO
var cooldowns := {"attack":0.0,"spin":0.0,"heal":0.0,"dash":0.0}
var resources: Array[Dictionary] = []
var enemies: Array[Dictionary] = []
var effects: Array[Dictionary] = []
var npc_position := Vector2(18.5,19)
var save_timer := 0.0
var sound_on := true
var audio: AudioStreamPlayer
var suspended := false

func noise_at(x: float, y: float) -> float:
	return fposmod(sin(x*127.1+y*311.7)*43758.5453,1.0)

func _ready() -> void:
	get_tree().auto_accept_quit = false
	state.load_game()
	create_world()
	world = AetheriaWorld.new()
	world.game = self
	add_child(world)
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = AetheriaHUD.new()
	hud.game = self
	layer.add_child(hud)
	audio = AudioStreamPlayer.new()
	add_child(audio)
	hud.notify("Fısıltılı Vadi'ye hoş geldin. İlk durağın: Tüccar Mira.")

func create_world() -> void:
	resources.clear()
	enemies.clear()
	for y in range(3,37):
		for x in range(3,37):
			if AetheriaState.terrain(x,y) != "grass" or Vector2(x-19,y-19).length()<4 or abs(x-y)<2 or (x>27 and y<16):
				continue
			var n := noise_at(x,y)
			if n>0.78:
				resources.append({"position":Vector2(x+0.5,y+0.5),"kind":"ore" if n>0.94 else "wood","ready":0.0})
	# Guaranteed starter materials avoid an unlucky resource distribution.
	for p in [Vector2(16,23),Vector2(17,24),Vector2(18,25),Vector2(21,24),Vector2(22,25)]:
		resources.append({"position":p,"kind":"wood","ready":0.0})
	for p in [Vector2(22,23),Vector2(23,24),Vector2(24,25)]:
		resources.append({"position":p,"kind":"ore","ready":0.0})
	for p in [Vector2(23,21),Vector2(25,23),Vector2(27,19),Vector2(24,17),Vector2(20,26)]:
		spawn_enemy(p,"wolf")
	if not state.boss_defeated:
		spawn_enemy(Vector2(32,12),"boss")

func spawn_enemy(at: Vector2, kind: String) -> void:
	var health := 420.0 if kind=="boss" else 74.0
	enemies.append({"position":at,"home":at,"kind":kind,"hp":health,"max_hp":health,"windup":0.0,"aim":at,"radius":2.8 if kind=="boss" else 1.5,"cooldown":1.0,"respawn":0.0,"flash":0.0})

func persist() -> void:
	if not state.save_game() and is_instance_valid(hud):
		hud.notify("Kayıt yazılamadı. Cihazın boş alanını kontrol et.")

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		suspended = true
		stick = Vector2.ZERO
		has_destination = false
		persist()
	elif what == NOTIFICATION_APPLICATION_RESUMED or what == NOTIFICATION_APPLICATION_FOCUS_IN:
		suspended = false
	elif what == NOTIFICATION_WM_GO_BACK_REQUEST or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if is_instance_valid(hud):
			if not hud.modal_mode.is_empty():
				hud.close_modal()
			else:
				hud.show_modal("exit")

func _process(delta: float) -> void:
	if suspended or not hud.modal_mode.is_empty():
		walking = false
		return
	var dt := minf(delta,0.05)
	clock += dt
	for action_name in cooldowns:
		cooldowns[action_name] = maxf(0.0,float(cooldowns[action_name])-dt)
	dash_left = maxf(0,dash_left-dt)
	state.mana = minf(60,state.mana+dt*2.4)
	var screen_direction := stick
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP): screen_direction.y -= 1
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN): screen_direction.y += 1
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT): screen_direction.x -= 1
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT): screen_direction.x += 1
	var direction := Vector2.ZERO
	if screen_direction.length()>0.15:
		direction = Vector2(screen_direction.x+screen_direction.y,screen_direction.y-screen_direction.x).normalized()
		has_destination = false
	elif has_destination:
		direction = destination-state.position
		if direction.length()<0.18:
			has_destination = false
			direction = Vector2.ZERO
		else:
			direction = direction.normalized()
	if dash_left > 0:
		direction = dash_direction
	var previous := state.position
	state.move(direction,dt,12.0 if dash_left>0 else 3.5)
	walking = previous.distance_to(state.position)>0.001
	if walking:
		last_direction = direction.normalized()
	elif has_destination:
		has_destination = false
	update_enemies(dt)
	effects = effects.filter(func(e: Dictionary) -> bool: return clock-e.start<e.life)
	save_timer += dt
	if save_timer>=3:
		persist()
		save_timer = 0

func update_enemies(dt: float) -> void:
	for enemy in enemies:
		if enemy.hp<=0:
			if enemy.kind!="boss" and enemy.respawn<=clock:
				enemy.hp = enemy.max_hp
				enemy.position = enemy.home
			continue
		enemy.flash = maxf(0,enemy.flash-dt)
		enemy.cooldown = maxf(0,enemy.cooldown-dt)
		if enemy.windup>0:
			enemy.windup = maxf(0,enemy.windup-dt)
			if enemy.windup<=0 and state.position.distance_to(enemy.aim)<enemy.radius and dash_left<=0:
				var damage := 24 if enemy.kind=="boss" else 9
				state.hp -= damage
				floating(state.position,"−%d" % damage,Color("eea38a"))
				if state.hp<=0:
					respawn()
					return
			continue
		var d: float = enemy.position.distance_to(state.position)
		var aggro := 6.5 if enemy.kind=="boss" else 5.0
		var safe: bool = state.position.distance_to(npc_position)<3.0
		if d<aggro and not safe and enemy.position.distance_to(enemy.home)<8:
			if d>(2.2 if enemy.kind=="boss" else 1.3):
				var velocity: Vector2 = (state.position-enemy.position).normalized()*dt*(1.1 if enemy.kind=="boss" else 1.5)
				if AetheriaState.walkable(enemy.position+velocity):
					enemy.position += velocity
			elif enemy.cooldown<=0:
				enemy.aim = state.position
				enemy.windup = 1.1 if enemy.kind=="boss" else 0.65
				enemy.cooldown = 2.6 if enemy.kind=="boss" else 1.9
		elif enemy.position.distance_to(enemy.home)>0.2:
			var step: Vector2 = (enemy.home-enemy.position).normalized()*dt
			if AetheriaState.walkable(enemy.position+step): enemy.position += step

func respawn() -> void:
	state.position = Vector2(19,21)
	state.hp = state.max_hp()
	state.mana = 60
	has_destination = false
	dash_left = 0
	for enemy in enemies:
		enemy.position = enemy.home
		enemy.windup = 0.0
		enemy.cooldown = 1.5
	hud.notify("Kampta yeniden doğdun. Eşyaların yanında.")
	persist()

func nearest_resource() -> Dictionary:
	var nearest: Dictionary = {}
	var best := 1.9
	for r in resources:
		if r.ready>clock:
			continue
		var d: float = state.position.distance_to(r.position)
		if d<best:
			best = d
			nearest = r
	return nearest

func action(name: String) -> void:
	if suspended or not hud.modal_mode.is_empty():
		return
	match name:
		"bag":
			hud.show_modal("inventory")
			return
		"interact":
			if state.position.distance_to(npc_position)<2:
				state.visited = true
				hud.notify("Mira: Hoş geldin! Ormanı temizle, kılıcını hazırla. Doğuda harabeler var.")
				tone(520)
			else:
				var r := nearest_resource()
				if r.is_empty():
					hud.notify("Kaynaklara veya Tüccar Mira'ya yaklaş.")
					return
				r.ready = clock+35
				if r.kind=="wood": state.wood += 1
				else: state.ore += 1
				state.gathered += 1
				grant_xp(12)
				floating(r.position,"+1 Odun" if r.kind=="wood" else "+1 Cevher",Color("ead49d"))
				tone(420)
			persist()
			return
	if cooldowns.get(name,0)>0:
		return
	if name=="dash":
		dash_direction = last_direction
		dash_left = 0.28
		cooldowns.dash = 3.0
		ring(state.position,Color("bbd4ca"),"ring")
		tone(270)
	elif name=="heal":
		if state.mana<20:
			hud.notify("İyileşme için 20 mana gerekli.")
			return
		if state.hp>=state.max_hp():
			hud.notify("Sağlığın zaten tam.")
			return
		state.mana -= 20
		state.hp = minf(state.max_hp(),state.hp+45)
		cooldowns.heal = 9.0
		floating(state.position,"+45",Color("b9d99c"))
		ring(state.position,Color("b1d49c"),"ring")
		tone(650)
	elif name=="attack" or name=="spin":
		var spin := name=="spin"
		if spin and state.mana<15:
			hud.notify("Kasırga için 15 mana gerekli.")
			return
		var targets: Array[Dictionary] = []
		for enemy in enemies:
			if enemy.hp>0 and state.position.distance_to(enemy.position)<(3.0 if spin else 2.0):
				targets.append(enemy)
		if targets.is_empty():
			hud.notify("Saldırmak için bir düşmana yaklaş.")
			return
		targets.sort_custom(func(a: Dictionary,b: Dictionary) -> bool: return state.position.distance_to(a.position)<state.position.distance_to(b.position))
		if spin: state.mana -= 15
		cooldowns[name] = 5.0 if spin else 0.55
		ring(state.position,Color("b8dad1") if spin else Color("edd1a0"),"ring" if spin else "slash")
		for enemy in targets:
			damage_enemy(enemy,state.attack_damage()+(12 if spin else 0))
			if not spin: break
		tone(180 if spin else 320)
	persist()

func damage_enemy(enemy: Dictionary, amount: int) -> void:
	enemy.hp = maxf(0,enemy.hp-amount)
	enemy.flash = 0.18
	floating(enemy.position,str(amount),Color("f4d5a0"))
	if enemy.hp<=0:
		enemy.windup = 0
		enemy.respawn = clock+30
		if enemy.kind=="boss":
			state.boss_defeated = true
			state.gold += 75
			grant_xp(150)
			hud.notify("Kadim Muhafız yenildi! +75 altın. Görev ödülünü al.")
		else:
			state.kills += 1
			state.gold += 8
			grant_xp(25)
		persist()

func sell_wood() -> void:
	if state.position.distance_to(npc_position)>=2 or state.wood<3:
		return
	state.wood -= 3
	state.gold += 12
	hud.notify("Mira: 3 odun için 12 altın. Yolun açık olsun!")
	persist()

func grant_xp(amount: int) -> void:
	if state.add_xp(amount):
		hud.notify("Seviye %d! Sağlığın tamamen yenilendi." % state.level)
		tone(740)

func floating(at: Vector2, text: String, color: Color) -> void:
	effects.append({"position":at,"text":text,"color":color,"start":clock,"life":1.0,"kind":"text"})

func ring(at: Vector2, color: Color, kind: String) -> void:
	effects.append({"position":at,"color":color,"start":clock,"life":0.4,"kind":kind})

func tone(frequency: float) -> void:
	if not sound_on or audio == null:
		return
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = 22050
	var samples := PackedByteArray()
	samples.resize(4410)
	for i in 2205:
		var amplitude := sin(TAU*frequency*i/22050)*1800*(1.0-i/2205.0)
		samples.encode_s16(i*2,int(amplitude))
	stream.data = samples
	audio.stream = stream
	audio.play()

func _input(event: InputEvent) -> void:
	if not is_instance_valid(hud):
		return
	if event is InputEventScreenTouch and event.pressed and hud.handle_touch(event.position):
		get_viewport().set_input_as_handled()
		return
	if not hud.modal_mode.is_empty():
		return
	if event is InputEventScreenTouch:
		if event.pressed and hud.joystick_pointer == -1 and event.position.distance_to(hud.joystick_center)<90:
			hud.joystick_pointer = event.index
			set_stick(event.position)
			get_viewport().set_input_as_handled()
		elif not event.pressed and event.index==hud.joystick_pointer:
			hud.joystick_pointer = -1
			stick = Vector2.ZERO
			hud.joystick_offset = Vector2.ZERO
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and event.index==hud.joystick_pointer:
		set_stick(event.position)
		get_viewport().set_input_as_handled()
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_SPACE,KEY_1: action("attack")
			KEY_2: action("spin")
			KEY_3: action("heal")
			KEY_4: action("dash")
			KEY_E: action("interact")
			KEY_I: action("bag")

func set_stick(at: Vector2) -> void:
	hud.joystick_offset = (at-hud.joystick_center).limit_length(38)
	stick = hud.joystick_offset/38
	has_destination = false

func _unhandled_input(event: InputEvent) -> void:
	if suspended or not hud.modal_mode.is_empty():
		return
	var at := Vector2.ZERO
	var tapped := false
	if event is InputEventScreenTouch and event.pressed:
		at = event.position
		tapped = true
	elif event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
		at = event.position
		tapped = true
	if tapped:
		destination = world.unproject(at)
		has_destination = true

func _exit_tree() -> void:
	if is_instance_valid(audio):
		audio.stop()
		audio.stream = null
