class_name AetheriaState
extends RefCounted

const SAVE_PATH := "user://journey_v1.json"
const WORLD_SIZE := 40
var position := Vector2(19, 21)
var hp := 100.0
var mana := 60.0
var level := 1
var xp := 0
var gold := 0
var wood := 0
var ore := 0
var kills := 0
var gathered := 0
var visited := false
var weapon := 1
var boss_defeated := false
var rewarded: Array[int] = []

func max_hp() -> float:
	return 100.0 + (level - 1) * 20.0

func attack_damage() -> int:
	return 23 + weapon * 7 + level * 2

func add_xp(amount: int) -> bool:
	xp += amount
	var leveled := false
	while xp >= level * 100:
		xp -= level * 100
		level += 1
		hp = max_hp()
		leveled = true
	return leveled

func objectives() -> Array[Dictionary]:
	return [
		{"title": "Mira ile tanış", "done": visited, "progress": "1/1" if visited else "0/1", "hint": "Köydeki altın işaretli tüccara yaklaş."},
		{"title": "Vadi kaynakları", "done": gathered >= 5, "progress": "%d/5" % mini(gathered, 5), "hint": "Ağaç ve cevherlerin yanında TOPLA'ya bas."},
		{"title": "Ormanı güvene al", "done": kills >= 3, "progress": "%d/3" % mini(kills, 3), "hint": "Köyün doğusundaki üç yaban kurdunu yen."},
		{"title": "Kılıcını güçlendir", "done": weapon >= 2, "progress": "1/1" if weapon >= 2 else "0/1", "hint": "5 odun + 3 cevherle çantadan üret."},
		{"title": "Kadim muhafız", "done": boss_defeated, "progress": "1/1" if boss_defeated else "0/1", "hint": "Doğudaki harabeye ulaş ve muhafızı yen."}
	]

func claim(index: int) -> bool:
	if index < 0 or index >= objectives().size() or index in rewarded:
		return false
	if not objectives()[index].done:
		return false
	rewarded.append(index)
	gold += 25 if index < 4 else 100
	add_xp(40 if index < 4 else 150)
	return true

func craft() -> bool:
	if wood < 5 or ore < 3 or weapon >= 3:
		return false
	wood -= 5
	ore -= 3
	weapon += 1
	return true

static func terrain(x: int, y: int) -> String:
	if x < 1 or y < 1 or x >= WORLD_SIZE - 1 or y >= WORLD_SIZE - 1:
		return "edge"
	if Vector2(x - 10, y - 13).length_squared() < 23 or Vector2(x - 28, y - 30).length_squared() < 14:
		return "water"
	return "grass"

static func walkable(p: Vector2) -> bool:
	return terrain(floori(p.x), floori(p.y)) == "grass"

func move(direction: Vector2, delta: float, speed := 3.5) -> void:
	var step := direction.limit_length() * speed * delta
	if walkable(position + Vector2(step.x, 0)):
		position.x += step.x
	if walkable(position + Vector2(0, step.y)):
		position.y += step.y

func data() -> Dictionary:
	return {"schema": 1, "x": position.x, "y": position.y, "hp": hp, "mana": mana, "level": level, "xp": xp, "gold": gold, "wood": wood, "ore": ore, "kills": kills, "gathered": gathered, "visited": visited, "weapon": weapon, "boss_defeated": boss_defeated, "rewarded": rewarded}

func apply_data(d: Dictionary) -> void:
	for key in ["level", "xp", "gold", "wood", "ore", "kills", "gathered", "weapon"]:
		if (d.get(key) is float or d.get(key) is int) and is_finite(float(d[key])):
			set(key, clampi(int(d[key]), 0, 1000000))
	level = clampi(level, 1, 50)
	weapon = clampi(weapon, 1, 3)
	for key in ["visited", "boss_defeated"]:
		if d.get(key) is bool:
			set(key, d[key])
	for key in ["hp", "mana"]:
		if (d.get(key) is float or d.get(key) is int) and is_finite(float(d[key])):
			set(key, clampf(float(d[key]), 0.0, max_hp() if key == "hp" else 60.0))
	if (d.get("x") is float or d.get("x") is int) and (d.get("y") is float or d.get("y") is int):
		var p := Vector2(float(d.x), float(d.y))
		if is_finite(p.x) and is_finite(p.y) and walkable(p):
			position = p
	rewarded.clear()
	if d.get("rewarded") is Array:
		for n in d.rewarded:
			if (n is int or n is float) and int(n) >= 0 and int(n) < 5 and int(n) not in rewarded:
				rewarded.append(int(n))

func save_game() -> bool:
	# Temporary file + rename protects the previous save if writing is interrupted.
	var file := FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(data()))
	file.flush()
	var error := file.get_error()
	file.close()
	if error != OK:
		return false
	return DirAccess.rename_absolute(SAVE_PATH + ".tmp", SAVE_PATH) == OK

func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
	if not parsed is Dictionary:
		return false
	apply_data(parsed)
	return true
