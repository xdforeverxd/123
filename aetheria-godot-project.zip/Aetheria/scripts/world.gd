class_name AetheriaWorld
extends Node2D

var game: Node
var font: Font = ThemeDB.fallback_font
const TILE := Vector2(48, 24)

func project(p: Vector2, height := 0.0) -> Vector2:
	var relative: Vector2 = p - game.state.position
	return get_viewport_rect().size * Vector2(0.5, 0.54) + Vector2((relative.x - relative.y) * TILE.x, (relative.x + relative.y) * TILE.y - height)

func unproject(p: Vector2) -> Vector2:
	var relative := p - get_viewport_rect().size * Vector2(0.5, 0.54)
	return game.state.position + Vector2((relative.x / TILE.x + relative.y / TILE.y) * 0.5, (relative.y / TILE.y - relative.x / TILE.x) * 0.5)

func poly(points: Array, color: Color) -> void:
	draw_colored_polygon(PackedVector2Array(points), color)

func oval(p: Vector2, radius: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in 20:
		points.append(p + Vector2(cos(i * TAU / 20), sin(i * TAU / 20)) * radius)
	draw_colored_polygon(points, color)

func label_at(text: String, p: Vector2, color := Color("e4d5af"), size := 16) -> void:
	var offset := Vector2(-font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x / 2, 0)
	draw_string(font, p + offset + Vector2(1, 2), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color("11241c"))
	draw_string(font, p + offset, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _process(_delta: float) -> void:
	queue_redraw()

func _draw() -> void:
	if game == null:
		return
	var screen := get_viewport_rect().size
	for y in AetheriaState.WORLD_SIZE:
		for x in AetheriaState.WORLD_SIZE:
			var p := project(Vector2(x, y))
			if p.x < -100 or p.x > screen.x + 100 or p.y < -110 or p.y > screen.y + 110:
				continue
			var kind := AetheriaState.terrain(x, y)
			var noise: float = game.noise_at(x, y)
			var trail: bool = absi(x - y) < 2 or (absi(y - 20) < 2 and x > 14 and x < 32)
			var ruins: bool = x > 27 and y < 16
			var color := Color("607e50").lightened(noise * 0.1)
			if trail:
				color = Color("8e8d65").lightened(noise * 0.07)
			if ruins:
				color = Color("64746b").lightened(noise * 0.08)
			if kind == "water":
				color = Color("365e59").lightened(noise * 0.16)
			if kind == "edge":
				color = Color("233e30")
			poly([p, project(Vector2(x+1, y)), project(Vector2(x+1, y+1)), project(Vector2(x, y+1))], color)
			if kind == "water":
				draw_line(p + Vector2(-8, 14), p + Vector2(10 + sin(game.clock * 1.5 + x) * 4, 14), Color(0.7, 0.85, 0.73, 0.25), 1)
			elif not trail and noise > 0.65:
				draw_line(p + Vector2(4, 16), p + Vector2(7, 9), Color("8ca268"), 1)
				if noise > 0.95:
					draw_circle(p + Vector2(2, 13), 2, Color("d0c49c"))
	for enemy in game.enemies:
		if enemy.hp > 0 and enemy.windup > 0:
			var p := project(enemy.aim)
			oval(p, Vector2(enemy.radius * 67, enemy.radius * 33), Color(0.8, 0.24, 0.15, 0.13 + enemy.windup * 0.2))
			draw_arc(p, enemy.radius * 38, 0, TAU, 32, Color("c98a63"), 2)
	var objects: Array[Dictionary] = []
	for r in game.resources:
		if r.ready <= game.clock:
			objects.append({"position": r.position, "kind": r.kind})
	objects.append({"position": Vector2(18, 16), "kind": "house"})
	objects.append({"position": Vector2(20, 16), "kind": "house"})
	objects.append({"position": game.npc_position, "kind": "npc"})
	objects.append({"position": Vector2(30, 12), "kind": "ruin"})
	for enemy in game.enemies:
		if enemy.hp > 0:
			objects.append({"position": enemy.position, "kind": "enemy", "enemy": enemy})
	objects.append({"position": game.state.position, "kind": "player"})
	objects.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return a.position.x + a.position.y < b.position.x + b.position.y)
	for object in objects:
		var p := project(object.position)
		if p.x < -150 or p.x > screen.x + 150 or p.y < -180 or p.y > screen.y + 180:
			continue
		match object.kind:
			"wood": tree(p)
			"ore": rock(p)
			"house": house(p)
			"ruin": ruin(p)
			"npc": human(p, false)
			"player": human(p, true)
			"enemy": monster(p, object.enemy)
	for effect in game.effects:
		var age: float = game.clock - effect.start
		var alpha: float = clampf(1.0 - age / effect.life, 0, 1)
		var color: Color = effect.color
		color.a = alpha
		var p := project(effect.position)
		if effect.kind == "text":
			label_at(effect.text, p + Vector2(0, -65 - age * 42), color, 23)
		else:
			var radius: float = (age / effect.life) * 95
			draw_arc(p, radius, -PI * 0.8, PI * 0.15 if effect.kind == "slash" else TAU, 32, color, 4)
	for i in 12:
		var p := Vector2(fposmod(i * 127.7 + sin(game.clock * 0.3 + i) * 25, screen.x), fposmod(i * 93.4 + cos(game.clock * 0.5 + i) * 16, screen.y))
		draw_circle(p, 1.6, Color(0.9, 0.85, 0.6, 0.25 + sin(game.clock+i) * 0.15))

func tree(p: Vector2) -> void:
	oval(p + Vector2(10, 2), Vector2(33, 12), Color(0.03, 0.1, 0.06, 0.25))
	poly([p+Vector2(-5,0),p+Vector2(5,0),p+Vector2(3,-50),p+Vector2(-3,-50)], Color("514c31"))
	for i in 3:
		var y := -29.0 - i * 23
		var width := 35.0 - i * 7
		poly([p+Vector2(-width,y),p+Vector2(0,y-54),p+Vector2(width,y),p+Vector2(8,y+7)], Color("2c5139").lightened(i*0.045))
		poly([p+Vector2(-width,y),p+Vector2(0,y-54),p+Vector2(0,y-3)], Color("416840").lightened(i*0.035))

func rock(p: Vector2) -> void:
	oval(p, Vector2(25,10),Color(0.03,0.1,0.06,0.25))
	poly([p+Vector2(-24,-3),p+Vector2(-20,-25),p+Vector2(0,-35),p+Vector2(23,-17),p+Vector2(26,1),p+Vector2(2,8)],Color("667e77"))
	poly([p+Vector2(-20,-25),p+Vector2(0,-35),p+Vector2(23,-17),p+Vector2(0,-13)],Color("a1b6a6"))
	draw_line(p+Vector2(-4,-20),p+Vector2(0,-30),Color("afdcd0"),4)
	draw_line(p+Vector2(11,-9),p+Vector2(16,-17),Color("afdcd0"),4)

func house(p: Vector2) -> void:
	oval(p, Vector2(74,25),Color(0.03,0.1,0.06,0.25))
	poly([p+Vector2(-56,-10),p+Vector2(0,17),p+Vector2(0,-61),p+Vector2(-56,-88)],Color("a4946a"))
	poly([p+Vector2(0,17),p+Vector2(56,-10),p+Vector2(56,-88),p+Vector2(0,-61)],Color("78714f"))
	poly([p+Vector2(-69,-86),p+Vector2(-8,-138),p+Vector2(16,-107),p+Vector2(0,-50)],Color("7c5b36"))
	poly([p+Vector2(-8,-138),p+Vector2(62,-104),p+Vector2(71,-81),p+Vector2(0,-50),p+Vector2(16,-107)],Color("ac834c"))
	for i in 6:
		draw_line(p+Vector2(-58+i*10,-86-i*6),p+Vector2(-3+i*3,-57-i*8),Color("5d4b33"),2)
	poly([p+Vector2(16,9),p+Vector2(37,-2),p+Vector2(37,-48),p+Vector2(16,-38)],Color("293c2c"))
	poly([p+Vector2(-42,-38),p+Vector2(-20,-27),p+Vector2(-20,-50),p+Vector2(-42,-61)],Color("d3b776"))
	draw_line(p+Vector2(-31,-55),p+Vector2(-31,-32),Color("5e5135"),3)

func ruin(p: Vector2) -> void:
	oval(p,Vector2(85,32),Color(0.04,0.1,0.1,0.3))
	for dx in [-64,64]:
		poly([p+Vector2(dx-14,0),p+Vector2(dx+14,8),p+Vector2(dx+14,-118),p+Vector2(dx-14,-126)],Color("72867d"))
		poly([p+Vector2(dx+14,8),p+Vector2(dx+28,0),p+Vector2(dx+28,-126),p+Vector2(dx+14,-118)],Color("4a665c"))
		draw_line(p+Vector2(dx,-35),p+Vector2(dx+18,-28),Color("3b554b"),3)
	poly([p+Vector2(-78,-119),p+Vector2(78,-119),p+Vector2(90,-142),p+Vector2(-60,-150)],Color("899c8a"))
	label_at("KADİM HARABE",p+Vector2(0,-168),Color("c9bd99"),14)

func human(p: Vector2, player: bool) -> void:
	oval(p+Vector2(2,3),Vector2(17,7),Color(0.02,0.08,0.05,0.5))
	if player:
		oval(p+Vector2(0,3),Vector2(23,10),Color(0.8,0.8,0.55,0.15))
	var moving: bool = player and game.walking
	var stride := sin(game.clock * 13) * 6 if moving else 0.0
	var bob := absf(stride)*0.3 if moving else sin(game.clock*2)*0.8
	p.y -= bob
	var armor := Color("b6c0ac") if player else Color("b49d70")
	var cloak := Color("397d85") if player else Color("788254")
	draw_line(p+Vector2(-7,-20),p+Vector2(-8-stride,-2),Color("394d42"),8)
	draw_line(p+Vector2(7,-20),p+Vector2(8+stride,-2),Color("394d42"),8)
	poly([p+Vector2(-12,-49),p+Vector2(10,-49),p+Vector2(20,-10),p+Vector2(0,-4),p+Vector2(-17,-17)],cloak)
	poly([p+Vector2(-12,-47),p+Vector2(9,-47),p+Vector2(11,-22),p+Vector2(-9,-18)],armor)
	draw_circle(p+Vector2(-13,-40),7,armor.lightened(0.1))
	draw_circle(p+Vector2(12,-40),7,armor.darkened(0.1))
	draw_line(p+Vector2(15,-34),p+Vector2(20,-16),Color("cfb58a"),6)
	if player:
		var swing := maxf(0, game.cooldowns.attack - 0.23) * 4.0
		var tip := p+Vector2(34,-53).rotated(swing)
		draw_line(p+Vector2(20,-18),tip,Color("dbe4cf"),4)
		draw_line(p+Vector2(16,-24),p+Vector2(29,-19),Color("d7b573"),4)
		poly([p+Vector2(-24,-37),p+Vector2(-10,-32),p+Vector2(-11,-17),p+Vector2(-20,-12),p+Vector2(-28,-27)],Color("6c9083"))
	draw_circle(p+Vector2(0,-59),9,Color("ccb58b"))
	poly([p+Vector2(-9,-60),p+Vector2(-6,-71),p+Vector2(6,-71),p+Vector2(11,-59),p+Vector2(0,-64)],Color("aebcad") if player else Color("665a40"))
	label_at("Gezgin" if player else "Tüccar Mira",p+Vector2(0,-83),Color("f0e8c9") if player else Color("dfc387"),15)
	if not player:
		label_at("◆",p+Vector2(0,-110),Color("dbbf77"),25)

func monster(p: Vector2, enemy: Dictionary) -> void:
	var boss: bool = enemy.kind == "boss"
	var flash: bool = enemy.flash > 0
	oval(p+Vector2(0,4),Vector2(36,14) if boss else Vector2(23,8),Color(0.02,0.08,0.05,0.4))
	if boss:
		var stone := Color("a0ada0") if flash else Color("6c8580")
		var bob := sin(game.clock * 2) * 3
		poly([p+Vector2(-24,-90+bob),p+Vector2(23,-90+bob),p+Vector2(31,-35),p+Vector2(-25,-35)],stone)
		draw_line(p+Vector2(-16,-39),p+Vector2(-20,0),Color("456057"),17)
		draw_line(p+Vector2(18,-39),p+Vector2(22,0),Color("456057"),17)
		draw_line(p+Vector2(-30,-77),p+Vector2(-42,-35),stone,18)
		draw_line(p+Vector2(31,-76),p+Vector2(43,-33),stone,18)
		draw_circle(p+Vector2(0,-104+bob),21,stone.lightened(0.1))
		draw_line(p+Vector2(-10,-105+bob),p+Vector2(-3,-103+bob),Color("d7d89d"),4)
		draw_line(p+Vector2(6,-103+bob),p+Vector2(13,-105+bob),Color("d7d89d"),4)
		draw_circle(p+Vector2(0,-66+bob),7,Color("a5d1bd"))
	else:
		var fur := Color("d5baa0") if flash else Color("87968a")
		var stride := sin(game.clock*10+enemy.home.x)*5
		draw_line(p+Vector2(-14,-14),p+Vector2(-14+stride,1),Color("5f7467"),5)
		draw_line(p+Vector2(12,-14),p+Vector2(12-stride,1),Color("5f7467"),5)
		oval(p+Vector2(0,-22),Vector2(23,12),fur)
		poly([p+Vector2(-17,-24),p+Vector2(-34,-33),p+Vector2(-24,-14)],fur)
		draw_circle(p+Vector2(23,-29),12,fur.lightened(0.13))
		poly([p+Vector2(15,-36),p+Vector2(18,-49),p+Vector2(26,-37)],Color("667c6b"))
		draw_circle(p+Vector2(28,-31),2,Color("e5d59b"))
	if enemy.position.distance_to(game.state.position) < 5.0 or boss:
		var width := 100.0 if boss else 65.0
		var height := -143.0 if boss else -67.0
		label_at("Kadim Muhafız" if boss else "Yaban Kurdu",p+Vector2(0,height),Color("e1b69d"),14)
		draw_rect(Rect2(p+Vector2(-width/2,height+7),Vector2(width,5)),Color("162d24"))
		draw_rect(Rect2(p+Vector2(-width/2,height+7),Vector2(width*enemy.hp/enemy.max_hp,5)),Color("bd8060"))
