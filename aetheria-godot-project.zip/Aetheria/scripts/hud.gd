class_name AetheriaHUD
extends Control

var game: Node
var font: Font = ThemeDB.fallback_font
var hp_bar: ProgressBar
var mana_bar: ProgressBar
var hp_text: Label
var mana_text: Label
var level_text: Label
var gold_text: Label
var quest_labels: Array[Label] = []
var quest_hint: Label
var claim_button: Button
var skill_buttons: Dictionary = {}
var toast_label: Label
var interaction: Label
var map: Control
var modal: Control
var controls: Array[Control] = []
var joystick_center := Vector2.ZERO
var joystick_pointer := -1
var joystick_offset := Vector2.ZERO
var toast_left := 0.0
var inventory_content: Label
var craft_button: Button
var selling_button: Button
var modal_mode := ""

class MiniMap extends Control:
	var game: Node
	func _draw() -> void:
		if game == null:
			return
		var unit := size / AetheriaState.WORLD_SIZE
		for y in AetheriaState.WORLD_SIZE:
			for x in AetheriaState.WORLD_SIZE:
				var color := Color("587149")
				if AetheriaState.terrain(x,y) == "water":
					color = Color("56857b")
				elif abs(x-y) < 2:
					color = Color("a39e73")
				elif game.noise_at(x,y) > 0.72:
					color = Color("34583a")
				draw_rect(Rect2(Vector2(x,y)*unit,unit+Vector2.ONE),color)
		for e in game.enemies:
			if e.hp > 0:
				draw_circle(e.position*unit,3 if e.kind == "boss" else 1.5,Color("d89372"))
		draw_circle(game.npc_position*unit,3,Color("dec389"))
		draw_circle(game.state.position*unit,3.5,Color("fff0c5"))
		draw_arc(game.state.position*unit,6,0,TAU,20,Color("fff0c5"),1)

func box(color := Color("152a24"), border := Color("677155"), radius := 5) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(radius)
	return style

func panel(at: Vector2, dimensions: Vector2, parent: Node = self) -> Panel:
	var p := Panel.new()
	parent.add_child(p)
	p.position = at
	p.size = dimensions
	p.add_theme_stylebox_override("panel", box(Color(0.06,0.13,0.11,0.94),Color("526046")))
	return p

func label(text: String, at: Vector2, dimensions: Vector2, font_size := 16, color := Color("e9e1c9"), parent: Node = self) -> Label:
	var l := Label.new()
	parent.add_child(l)
	l.text = text
	l.position = at
	l.size = dimensions
	l.add_theme_font_size_override("font_size",font_size)
	l.add_theme_color_override("font_color",color)
	l.mouse_filter = MOUSE_FILTER_IGNORE
	return l

func button(text: String, at: Vector2, dimensions: Vector2, callback: Callable, parent: Node = self) -> Button:
	var b := Button.new()
	parent.add_child(b)
	b.text = text
	b.position = at
	b.size = dimensions
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size",15)
	b.add_theme_color_override("font_color",Color("e6d2a3"))
	b.add_theme_stylebox_override("normal",box(Color("293f32"),Color("a38e61")))
	b.add_theme_stylebox_override("pressed",box(Color("617450"),Color("e1c68c")))
	b.add_theme_stylebox_override("hover",box(Color("354d3b"),Color("c1a773")))
	b.pressed.connect(callback)
	return b

func progress(at: Vector2, dimensions: Vector2, color: Color, parent: Node) -> ProgressBar:
	var p := ProgressBar.new()
	parent.add_child(p)
	p.position = at
	p.size = dimensions
	p.show_percentage = false
	p.add_theme_font_size_override("font_size",1)
	p.add_theme_stylebox_override("background",box(Color("0b1914"),Color("334638"),1))
	p.add_theme_stylebox_override("fill",box(color,color,1))
	p.mouse_filter = MOUSE_FILTER_IGNORE
	return p

func _ready() -> void:
	mouse_filter = MOUSE_FILTER_IGNORE
	get_viewport().size_changed.connect(rebuild)
	rebuild()

func rebuild() -> void:
	var old_mode := modal_mode
	modal_mode = ""
	modal = null
	for child in get_children():
		remove_child(child)
		child.queue_free()
	quest_labels.clear()
	skill_buttons.clear()
	size = get_viewport_rect().size
	joystick_center = Vector2(90,size.y-90)
	joystick_offset = Vector2.ZERO
	joystick_pointer = -1
	game.stick = Vector2.ZERO
	var player := panel(Vector2(20,20),Vector2(230,90))
	level_text = label("GEZGİN · SV. 1",Vector2(14,8),Vector2(200,24),18,Color("e2d5ad"),player)
	hp_bar = progress(Vector2(14,39),Vector2(202,14),Color("91aa65"),player)
	mana_bar = progress(Vector2(14,62),Vector2(202,10),Color("648f9f"),player)
	hp_text = label("",Vector2(16,35),Vector2(196,20),12,Color("f0ecd8"),player)
	hp_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mana_text = label("",Vector2(16,59),Vector2(196,18),11,Color("e4e8dd"),player)
	mana_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var brand := label("✦ A E T H E R I A",Vector2(size.x/2-155,22),Vector2(310,35),24,Color("e3cca0"))
	brand.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var subtitle := label("KAYIP SINIRLAR   /   GODOT 4",Vector2(size.x/2-130,59),Vector2(260,20),10,Color("b4c5a8"))
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	button("?",Vector2(size.x-250,23),Vector2(46,46),func(): show_modal("guide"))
	var map_panel := panel(Vector2(size.x-186,20),Vector2(166,143))
	label("FISILTILI VADİ",Vector2(10,5),Vector2(148,18),11,Color("c8d0b5"),map_panel)
	map = MiniMap.new()
	map.game = game
	map_panel.add_child(map)
	map.position = Vector2(10,29)
	map.size = Vector2(146,101)
	var quests := panel(Vector2(20,122),Vector2(230,206))
	label("YOLCULUĞUN",Vector2(12,8),Vector2(210,20),12,Color("d4ba80"),quests)
	for i in 5:
		quest_labels.append(label("",Vector2(12,36+i*23),Vector2(210,23),13,Color("c5ceb7"),quests))
	claim_button = button("ÖDÜLÜ AL",Vector2(12,157),Vector2(206,38),claim_next,quests)
	quest_hint = label("",Vector2(16,159),Vector2(204,43),11,Color("99b08f"),quests)
	quest_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var actions := ["attack","spin","heal","dash","interact","bag"]
	var names := ["KILIÇ","KASIRGA","İYİLEŞ","KAÇIN","TOPLA","ÇANTA"]
	var symbols := ["╱","✺","+","»","♧","▣"]
	for i in actions.size():
		var action: String = actions[i]
		var b := button(symbols[i]+"\n"+names[i],Vector2(size.x-20-(actions.size()-i)*80,size.y-103),Vector2(72,76),func(): game.action(action))
		skill_buttons[action] = b
	gold_text = label("",Vector2(164,size.y-66),Vector2(170,30),19,Color("dfc587"))
	var footer := label("ANDROID  ·  TEK OYUNCULU",Vector2(size.x/2-120,size.y-21),Vector2(240,16),10,Color("a0b196"))
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label = label("",Vector2(size.x/2-230,88),Vector2(460,52),17,Color("f0d39a"))
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	interaction = label("",Vector2(size.x/2-200,size.y-151),Vector2(400,34),14,Color("f1d89d"))
	interaction.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	if not old_mode.is_empty():
		show_modal(old_mode)
	update_values()

func _process(delta: float) -> void:
	toast_left = maxf(0,toast_left-delta)
	toast_label.visible = toast_left > 0
	update_values()
	map.queue_redraw()
	queue_redraw()

func _draw() -> void:
	draw_circle(joystick_center,62,Color(0.7,0.8,0.6,0.06))
	draw_arc(joystick_center,62,0,TAU,48,Color(0.75,0.85,0.65,0.35),1.5)
	draw_circle(joystick_center+joystick_offset,25,Color(0.7,0.8,0.6,0.28))
	draw_arc(joystick_center+joystick_offset,25,0,TAU,32,Color(0.8,0.9,0.7,0.4),1)

func update_values() -> void:
	if game == null or hp_bar == null:
		return
	var s: AetheriaState = game.state
	level_text.text = "GEZGİN · SEVİYE %d" % s.level
	hp_bar.value = s.hp/s.max_hp()*100
	mana_bar.value = s.mana/60*100
	hp_text.text = "%d / %d" % [ceili(s.hp),int(s.max_hp())]
	mana_text.text = "%d / 60 MANA" % int(s.mana)
	gold_text.text = "◈ %d ALTIN" % s.gold
	var tasks := s.objectives()
	var hint := "Vadiyi keşfetmeye devam et."
	var found_hint := false
	var claimable := false
	for i in tasks.size():
		quest_labels[i].text = ("✓ " if tasks[i].done else "◇ ") + tasks[i].title + "  " + tasks[i].progress
		quest_labels[i].modulate = Color("d7c28a") if tasks[i].done else Color.WHITE
		if tasks[i].done and i not in s.rewarded:
			claimable = true
		if not tasks[i].done and not found_hint:
			hint = tasks[i].hint
			found_hint = true
	claim_button.visible = claimable
	quest_hint.visible = not claimable
	quest_hint.text = hint
	var names := {"attack":"KILIÇ","spin":"KASIRGA","heal":"İYİLEŞ","dash":"KAÇIN"}
	var icons := {"attack":"╱","spin":"✺","heal":"+","dash":"»"}
	for action in names:
		var cooldown: float = game.cooldowns.get(action,0)
		skill_buttons[action].text = ("%d" % ceili(cooldown) if cooldown > 0 else icons[action])+"\n"+names[action]
		skill_buttons[action].modulate = Color(0.7,0.75,0.65) if cooldown > 0 else Color.WHITE
	var nearby: Dictionary = game.nearest_resource()
	interaction.text = ""
	if s.position.distance_to(game.npc_position) < 2.0:
		interaction.text = "Mira ile konuşmak için TOPLA'ya dokun"
	elif not nearby.is_empty():
		interaction.text = ("Odun topla" if nearby.kind == "wood" else "Demir cevheri çıkar")+" · TOPLA"
	if modal_mode == "inventory" and is_instance_valid(inventory_content):
		inventory_content.text = "ODUN: %d       DEMİR: %d       ALTIN: %d\n\nKılıç seviyesi: %d / 3   ·   Hasar: %d\n\nÜretim: 5 odun + 3 demir cevheri" % [s.wood,s.ore,s.gold,s.weapon,s.attack_damage()]
		craft_button.disabled = s.wood<5 or s.ore<3 or s.weapon>=3
		selling_button.disabled = s.wood<3 or s.position.distance_to(game.npc_position)>=2

func notify(text: String) -> void:
	toast_label.text = text
	toast_left = 3.0

func claim_next() -> void:
	for i in 5:
		if game.state.claim(i):
			game.persist()
			notify("Görev tamamlandı! +%d altın ve deneyim." % (25 if i<4 else 100))
			game.tone(660)
			return

func close_modal() -> void:
	if is_instance_valid(modal):
		modal.queue_free()
	modal = null
	modal_mode = ""
	game.stick = Vector2.ZERO
	joystick_pointer = -1
	joystick_offset = Vector2.ZERO

func show_modal(mode: String) -> void:
	close_modal()
	modal_mode = mode
	modal = Control.new()
	add_child(modal)
	modal.size = size
	var shade := ColorRect.new()
	modal.add_child(shade)
	shade.size = size
	shade.color = Color(0.02,0.06,0.04,0.88)
	var p := panel((size-Vector2(620,440))/2,Vector2(620,440),modal)
	label("GEZGİNİN YOLCULUĞU",Vector2(24,18),Vector2(520,24),12,Color("c5b17b"),p)
	button("×",Vector2(550,12),Vector2(48,48),close_modal,p)
	if mode == "inventory":
		label("Envanter & Zanaat",Vector2(24,50),Vector2(540,42),27,Color("e6dbba"),p)
		inventory_content = label("",Vector2(24,116),Vector2(565,150),19,Color("c6d0b7"),p)
		craft_button = button("KILICI GELİŞTİR",Vector2(24,282),Vector2(264,58),craft_item,p)
		selling_button = button("3 ODUN SAT · 12 ALTIN",Vector2(304,282),Vector2(292,58),func(): game.sell_wood(),p)
		label("Satış için Mira'nın yanında olmalısın.\nİlerlemen cihazına otomatik kaydedilir.",Vector2(24,359),Vector2(565,52),14,Color("a4b399"),p)
	elif mode == "exit":
		label("Yolculuğa ara ver?",Vector2(24,72),Vector2(560,48),28,Color("e6dbba"),p)
		label("İlerlemen bu cihazda kaydedilir.",Vector2(24,152),Vector2(565,50),19,Color("c6d0b7"),p)
		button("DEVAM ET",Vector2(24,278),Vector2(270,62),close_modal,p)
		button("KAYDET VE ÇIK",Vector2(310,278),Vector2(286,62),func(): game.persist(); get_tree().quit(),p)
	else:
		label("Vadi seni bekliyor.",Vector2(24,56),Vector2(540,44),28,Color("e6dbba"),p)
		label("Sol kumanda: hareket et   ·   Yere dokun: hedefe yürü\nKILIÇ: yakındaki hedefe saldır   ·   KASIRGA: alan saldırısı\nKAÇIN: kısa süreli hızlı hareket ve hasardan korunma\nİYİLEŞ: 20 mana harcayarak 45 sağlık yenile\nTOPLA: kaynak topla veya Mira ile konuş\nÇANTA: kaynaklarını gör, kılıcını güçlendir\n\nDoğudaki harabede Kadim Muhafız seni bekliyor.\nKırmızı saldırı uyarısından KAÇIN ile uzaklaş!",Vector2(24,124),Vector2(570,240),16,Color("c4ceb6"),p)
		button("YOLCULUĞA DEVAM ET",Vector2(24,364),Vector2(410,52),close_modal,p)
		button("SES: AÇIK" if game.sound_on else "SES: KAPALI",Vector2(450,364),Vector2(146,52),func(): game.sound_on=not game.sound_on; show_modal("guide"),p)

func craft_item() -> void:
	if game.state.craft():
		game.persist()
		notify("Kılıcın güçlendi!")
		game.tone(540)

# Native Buttons use mouse emulation by default. Dispatch real touch presses
# explicitly so the second thumb can cast while the first holds the joystick.
func touched_button(at: Vector2, parent: Node) -> Button:
	var children := parent.get_children()
	children.reverse()
	for child in children:
		if child is Control and not child.is_visible_in_tree():
			continue
		var nested := touched_button(at,child)
		if nested != null:
			return nested
		if child is Button and not child.disabled and child.get_global_rect().has_point(at):
			return child
	return null

func handle_touch(at: Vector2) -> bool:
	var b := touched_button(at,modal if is_instance_valid(modal) else self)
	if b == null:
		return false
	b.pressed.emit()
	return true
