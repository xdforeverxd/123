"""Render a connected 3D client against a real local ENet server (requires DISPLAY)."""
import os
import subprocess
import tempfile
import time
from pathlib import Path

root = Path(__file__).resolve().parents[1]
godot = os.environ.get("GODOT", "/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64")
base = [godot, "--path", str(root / "godot")]
with tempfile.TemporaryDirectory(prefix="online-visual-") as directory:
    env = dict(os.environ, ONLINE_SAVE_DIRECTORY=directory + "/server", XDG_DATA_HOME=directory + "/client")
    server = subprocess.Popen(base + ["--headless", "res://online/arena.tscn", "--", "--server"], env=env,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        time.sleep(0.6)
        client = subprocess.run(base + ["--audio-driver", "Dummy", "--script", "tests/online_visual.gd", "--", "--connect"],
                                env=env, capture_output=True, text=True, timeout=40)
        print(client.stdout)
        print(client.stderr)
        assert client.returncode == 0 and "ONLINE_3D_RENDER_PASS" in client.stdout
        assert "ERROR:" not in client.stdout + client.stderr
    finally:
        server.terminate()
        output = server.communicate(timeout=5)[0]
        print(output)
        assert "ERROR:" not in output
