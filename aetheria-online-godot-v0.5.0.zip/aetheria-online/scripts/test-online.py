"""Real ENet integration: two clients, shared reward, server restart, restore."""
import os
import subprocess
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GODOT = os.environ.get("GODOT", "/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64")
BASE = [GODOT, "--headless", "--path", str(ROOT / "godot")]


def server(env):
    process = subprocess.Popen(BASE + ["res://online/arena.tscn", "--", "--server"], env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    time.sleep(1)
    if process.poll() is not None:
        raise RuntimeError(process.communicate()[0])
    return process


def clients(env, directory, restore=False):
    processes = []
    try:
        for index in range(2):
            settings = dict(env, ONLINE_TEST_IDENTITY=str(directory / f"client-{index}.json"),
                            ONLINE_TEST_RESTORE="1" if restore else "0")
            processes.append(subprocess.Popen(BASE + ["--script", "tests/online_probe.gd"], env=settings,
                                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True))
        for process in processes:
            output = process.communicate(timeout=18)[0]
            print(output)
            assert process.returncode == 0 and "ERROR:" not in output, output
    finally:
        for process in processes:
            if process.poll() is None:
                process.kill()
                process.communicate()


def stop(process):
    process.terminate()
    output = process.communicate(timeout=5)[0]
    print(output)
    assert "ERROR:" not in output, output


with tempfile.TemporaryDirectory(prefix="aetheria-online-") as temporary:
    directory = Path(temporary)
    env = dict(os.environ, ONLINE_SAVE_DIRECTORY=str(directory / "characters"))
    combat = subprocess.run(BASE + ["--script", "tests/online_combat.gd"], env=env,
                            capture_output=True, text=True, timeout=10)
    print(combat.stdout)
    assert combat.returncode == 0 and "ONLINE_COMBAT_PASS" in combat.stdout, combat.stderr
    check = subprocess.run(BASE + ["--script", "tests/online_store.gd"], env=env,
                           capture_output=True, text=True, timeout=10)
    print(check.stdout)
    assert check.returncode == 0 and "ONLINE_STORE_PASS" in check.stdout, check.stderr
    # Remove the intentionally corrupt fixture before integration checks.
    for fixture in (directory / "characters").glob("*.json"):
        fixture.unlink()
    process = server(env)
    try:
        clients(env, directory)
        time.sleep(0.4)  # Let reliable disconnect events flush position saves.
    finally:
        stop(process)
    assert len(list((directory / "characters").glob("*.json"))) == 2
    process = server(env)
    try:
        clients(env, directory, restore=True)
    finally:
        stop(process)
print("PASS: two players retain separate identities, position and rewards across server restart")
