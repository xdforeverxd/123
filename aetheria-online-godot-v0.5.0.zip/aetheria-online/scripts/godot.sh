#!/usr/bin/env bash
set -euo pipefail
project_root="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
if [[ -n "${GODOT_BIN:-}" ]]; then
  godot_bin="$GODOT_BIN"
elif command -v godot >/dev/null 2>&1; then
  godot_bin="$(command -v godot)"
elif [[ -x /opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64 ]]; then
  godot_bin=/opt/godot/4.6.3/Godot_v4.6.3-stable_linux.x86_64
else
  echo 'Godot 4.6.3 gerekli. GODOT_BIN ile yürütülebilir dosyanın yolunu belirtin.' >&2
  exit 1
fi
case "${1:-editor}" in
  editor) exec "$godot_bin" --editor --path "$project_root/godot" ;;
  test)
    test_data="$(mktemp -d /tmp/aetheria-native-tests.XXXXXX)"
    trap 'rm -rf -- "$test_data"' EXIT
    "$godot_bin" --headless --editor --path "$project_root/godot" --import --quit
    XDG_DATA_HOME="$test_data" "$godot_bin" --headless --path "$project_root/godot" --script tests/test_runner.gd
    ;;
  android)
    mkdir -p "$project_root/dist"
    exec "$godot_bin" --headless --path "$project_root/godot" --export-debug Android "$project_root/dist/aetheria-godot-android-debug.apk"
    ;;
  run) exec "$godot_bin" --path "$project_root/godot" ;;
  *) echo 'Kullanım: scripts/godot.sh [editor|test|android|run]' >&2; exit 2 ;;
esac
