extends SceneTree

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size()!=4 or args[0]!="--placements" or args[2]!="--output":
		printerr("Expected --placements file.json --output file.tscn")
		quit(2)
		return
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(args[1]))
	if not data is Dictionary or data.get("schema")!=1 or data.get("gameplay_ready",true)!=false or not data.get("points") is Array:
		printerr("Invalid research placement manifest")
		quit(1)
		return
	var scene := Node3D.new()
	scene.name = "AllodsRawCoordinateInspection"
	scene.set_meta("coordinate_mapping","Raw XYZ identity; engine axis convention and units are not verified")
	scene.set_meta("gameplay_ready",false)
	for i in data.points.size():
		var point: Variant = data.points[i]
		if not point is Dictionary or not point.get("raw_xyz") is Array or point.raw_xyz.size()!=3:
			scene.free()
			printerr("Invalid coordinate entry")
			quit(1)
			return
		for value in point.raw_xyz:
			if typeof(value) not in [TYPE_INT,TYPE_FLOAT]:
				scene.free()
				printerr("Coordinates must be numeric")
				quit(1)
				return
		var marker := Marker3D.new()
		marker.name = "Point_%04d" % i
		marker.position = Vector3(point.raw_xyz[0],point.raw_xyz[1],point.raw_xyz[2])
		if not marker.position.is_finite():
			marker.free()
			scene.free()
			printerr("Non-finite coordinates")
			quit(1)
			return
		marker.set_meta("source_type",point.type)
		marker.set_meta("source_record",point.record)
		marker.set_meta("spawn_time_type",point.spawn_time_type)
		scene.add_child(marker)
		marker.owner = scene
	var packed := PackedScene.new()
	if packed.pack(scene)!=OK or ResourceSaver.save(packed,args[3])!=OK:
		scene.free()
		printerr("Could not save inspection scene")
		quit(1)
		return
	scene.free()
	var saved := load(args[3]) as PackedScene
	var restored := saved.instantiate()
	var count := restored.get_child_count()
	restored.free()
	if count!=data.points.size():
		printerr("Saved scene lost placement entries")
		quit(1)
		return
	print("RAW_PLACEMENT_IMPORT_OK: ",count," source coordinate markers saved and reloaded")
	print("NOT_PLAYABLE: no geometry, collision, animation, AI or spawn scripts are reconstructed")
	quit(0)
