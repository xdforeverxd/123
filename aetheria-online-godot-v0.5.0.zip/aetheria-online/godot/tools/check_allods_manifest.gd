extends SceneTree

# Read-only import contract for research metadata, not a gameplay converter.
func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	if args.size()!=2 or args[0]!="--manifest":
		printerr("Usage: --script tools/check_allods_manifest.gd -- --manifest /path/to/slice-manifest.json")
		quit(2)
		return
	if not FileAccess.file_exists(args[1]):
		printerr("Manifest not found")
		quit(2)
		return
	var report: Variant = JSON.parse_string(FileAccess.get_file_as_string(args[1]))
	if not report is Dictionary or report.get("schema")!=1:
		printerr("Invalid manifest schema")
		quit(1)
		return
	if report.get("complete_gameplay_or_asset_import",true)!=false:
		printerr("Research manifest must not claim a complete playable import")
		quit(1)
		return
	if not report.get("nodes") is Array or not report.get("warrior_skills") is Array or report.warrior_skills.size()!=3:
		printerr("Expected dependency inventory and three Warrior skill records")
		quit(1)
		return
	var missing := 0
	for node in report.nodes:
		if not node is Dictionary or not node.get("path") is String or not node.get("status") is String:
			printerr("Malformed dependency entry")
			quit(1)
			return
		if node.status=="not_found_at_exact_path": missing += 1
	for skill in report.warrior_skills:
		if not skill is Dictionary or not skill.get("prototype") is String or not skill.get("costs") is Array or not skill.get("cooldown") is Dictionary:
			printerr("Incomplete skill record")
			quit(1)
			return
		if not skill.cooldown.get("duration") is Dictionary or not skill.cooldown.duration.get("raw_value") is String:
			printerr("Missing raw cooldown value")
			quit(1)
			return
		print("IMPORTED: ",skill.path.get_base_dir().get_file(),"; duration raw = ",skill.cooldown.duration.raw_value)
	print("RESEARCH_IMPORT_OK: ",report.nodes.size()," dependency records; ",missing," unavailable exact paths")
	print("PLAYABLE_IMPORT_BLOCKED: assets, placement and engine-specific formulas are not validated")
	quit(0)
