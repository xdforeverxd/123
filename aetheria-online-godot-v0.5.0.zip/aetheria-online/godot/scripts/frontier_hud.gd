class_name FrontierHUD
extends AetheriaHUD

var target_text: Label
var zone_text: Label
var xp_text: Label

class RegionMap extends Control:
	var game: Node
	func _draw() -> void:
		if game==null: return
		var unit := size/FrontierMap.SIZE
		for y in FrontierMap.SIZE:
			for x in FrontierMap.SIZE:
				var p := Vector2(x,y)
				var zone := FrontierMap.zone_at(p)
				var color: Color = zone.color
				var kind := FrontierMap.terrain(Vector2i(x,y))
				if kind=="water": color = Color("41778d")
				elif kind in ["road","bridge"]: color = Color("c6b88e")
				if zone.id not in game.state.discovered: color = color.darkened(0.32)
				draw_rect(Rect2(p*unit,unit+Vector2.ONE),color)
		for p in game.path:
			draw_circle(Vector2(p)*unit,maxf(1,unit.x*0.25),Color("e4d194"))
		for enemy in game.enemies:
			if enemy.hp>0: draw_circle(enemy.position*unit,3 if enemy.kind=="boss" else 1.5,Color("db8d79"))
		for zone in FrontierMap.ZONES:
			draw_arc(zone.point*unit,3,0,TAU,16,Color("e4d9b8"),1)
		draw_circle(FrontierMap.NPC*unit,3,Color("edc776"))
		draw_circle(game.state.position*unit,4,Color("fff4d3"))
		draw_arc(game.state.position*unit,7,0,TAU,20,Color("fff4d3"),1)

func rebuild() -> void:
	super.rebuild()
	var quest_panel: Control = quest_labels[0].get_parent()
	quest_panel.size.y = 238
	for i in range(5,7): quest_labels.append(label("",Vector2.ZERO,Vector2(210,20),12,Color("c5ceb7"),quest_panel))
	for i in quest_labels.size():
		quest_labels[i].position = Vector2(12,34+i*20)
		quest_labels[i].add_theme_font_size_override("font_size",12)
	claim_button.position.y = 185
	claim_button.size.y = 40
	quest_hint.position.y = 182
	quest_hint.size.y = 48
	var parent := map.get_parent()
	parent.remove_child(map)
	map.queue_free()
	map = RegionMap.new()
	map.game = game
	parent.add_child(map)
	map.position = Vector2(10,29)
	map.size = Vector2(146,101)
	button("SINIFLAR",Vector2(262,20),Vector2(100,38),func(): show_modal("classes"))
	button("DÜNYA HARİTASI",Vector2(size.x-186,173),Vector2(166,40),func(): show_modal("map"))
	zone_text = label("",Vector2(size.x/2-175,76),Vector2(350,24),13,Color("c4d5b2"))
	zone_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	target_text = label("",Vector2(size.x/2-175,121),Vector2(350,42),15,Color("ebc098"))
	target_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	xp_text = label("",Vector2(164,size.y-39),Vector2(175,18),11,Color("b2c3a5"))
	update_values()

func update_values() -> void:
	if game==null or hp_bar==null: return
	var s: FrontierState = game.state
	level_text.text = "%s · SV. %d" % [s.definition().name.to_upper(),s.level]
	level_text.add_theme_font_size_override("font_size",14)
	hp_bar.value = s.hp/s.max_hp()*100
	mana_bar.value = s.mana/s.max_mana()*100
	hp_text.text = "%d / %d" % [ceili(s.hp),int(s.max_hp())]
	mana_text.text = "%d / %d MANA" % [int(s.mana),int(s.max_mana())]
	gold_text.text = "◈ %d ALTIN" % s.gold
	if is_instance_valid(zone_text): zone_text.text = FrontierMap.zone_at(s.position).name
	if is_instance_valid(xp_text): xp_text.text = "DENEYİM %d / %d" % [s.xp,s.level*100]
	if is_instance_valid(target_text):
		var enemy: Dictionary = game.selected_target()
		target_text.text = "%s · %d / %d" % [enemy.title,ceili(enemy.hp),int(enemy.max_hp)] if not enemy.is_empty() else ""
	var tasks := s.objectives()
	var claimable := false
	var hint := "Bölüm tamamlandı. Haritayı keşfet!"
	var found := false
	for i in mini(tasks.size(),quest_labels.size()):
		quest_labels[i].text = ("✓ " if tasks[i].done else "◇ ")+tasks[i].title+"  "+tasks[i].progress
		if tasks[i].done and i not in s.rewarded: claimable = true
		if not found and not tasks[i].done:
			hint = tasks[i].hint
			found = true
	claim_button.visible = claimable
	quest_hint.visible = not claimable
	quest_hint.text = hint
	var names := {"attack":"VURUŞ","spin":"YETENEK","heal":"İYİLEŞ","dash":"KAÇIN"}
	var icons := {"attack":"╱","spin":"✺","heal":"+","dash":"»"}
	for action_name in names:
		var wait: float = game.cooldowns.get(action_name,0)
		skill_buttons[action_name].text = (str(ceili(wait)) if wait>0 else icons[action_name])+"\n"+names[action_name]
		skill_buttons[action_name].modulate = Color(0.7,0.75,0.65) if wait>0 else Color.WHITE
	var nearby: Dictionary = game.nearest_resource()
	interaction.text = ""
	if s.position.distance_to(FrontierMap.NPC)<2:
		interaction.text = "TOPLA: Mira ile konuş / ÇANTA: ticaret"
	elif not nearby.is_empty(): interaction.text = "TOPLA: "+("Odun" if nearby.kind=="wood" else "Demir cevheri")
	if modal_mode=="inventory" and is_instance_valid(inventory_content):
		inventory_content.text = "ODUN: %d       DEMİR: %d       ALTIN: %d\n\nSilah: %d / 3   ·   Hasar: %d   ·   Menzil: %d m\n\nÜretim: 5 odun + 3 demir cevheri" % [s.wood,s.ore,s.gold,s.weapon,s.attack_damage(),int(s.definition().range*2)]
		craft_button.text = "SİLAHI GELİŞTİR"
		craft_button.disabled = s.wood<5 or s.ore<3 or s.weapon>=3
		selling_button.disabled = s.wood<3 or s.position.distance_to(FrontierMap.NPC)>=2

func claim_next() -> void:
	for i in 7:
		if game.state.claim(i):
			game.persist()
			notify("Görev ödülü alındı: altın ve deneyim!")
			game.tone(660)
			return

func show_modal(mode: String) -> void:
	if mode in ["inventory","exit"]:
		super.show_modal(mode)
		return
	close_modal()
	modal_mode = mode
	modal = Control.new()
	add_child(modal)
	modal.size = size
	var shade := ColorRect.new()
	modal.add_child(shade)
	shade.size = size
	shade.color = Color(0.02,0.06,0.04,0.9)
	var dimensions := Vector2(800,458) if mode=="map" else Vector2(760,458)
	var p := panel((size-dimensions)/2,dimensions,modal)
	button("×",Vector2(dimensions.x-60,10),Vector2(48,48),close_modal,p)
	label("AETHERIA · KAYIP SINIRLAR",Vector2(24,14),Vector2(570,24),12,Color("d7be83"),p)
	if mode=="classes":
		label("Savaş tarzını seç",Vector2(24,48),Vector2(600,36),25,Color("e5d4b4"),p)
		label("Sınıf değiştirmek için köyde ve savaş dışında olmalısın.",Vector2(24,91),Vector2(690,28),14,Color("b8c5a7"),p)
		var i := 0
		for id in FrontierClasses.DATA:
			var d: Dictionary = FrontierClasses.DATA[id]
			var card := panel(Vector2(24+i*179,134),Vector2(168,295),p)
			label(d.name,Vector2(10,12),Vector2(148,35),16,d.color.lightened(0.35),card)
			var description := label(d.role+"\n\n"+d.description+"\n\nSağlık %d · Mana %d" % [d.hp,d.mana],Vector2(10,54),Vector2(148,171),13,Color("cbd2bc"),card)
			description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			button("SEÇİLİ" if game.state.class_id==id else "SINIFI SEÇ",Vector2(10,239),Vector2(148,43),func(): game.choose_class(id),card)
			i += 1
	elif mode=="map":
		label("Fısıltılı Vadi · Bölge haritası",Vector2(24,46),Vector2(660,38),24,Color("e5d4b4"),p)
		var overview := RegionMap.new()
		overview.game = game
		p.add_child(overview)
		overview.position = Vector2(24,99)
		overview.size = Vector2(327,327)
		for i in FrontierMap.ZONES.size():
			var z: Dictionary = FrontierMap.ZONES[i]
			label(z.name+" · "+z.level,Vector2(375,100+i*61),Vector2(385,22),13,Color("d0d5bd"),p)
			button("YOL ÇİZ",Vector2(375,124+i*61),Vector2(360,31),func(): game.navigate(z.point); close_modal(),p)
	else:
		label("Yeni bir dünya seni bekliyor",Vector2(24,52),Vector2(670,40),26,Color("e5d4b4"),p)
		label("Sol kumanda: yürü   ·   Dünyaya dokun: engellerin çevresinden yol bul\nBoş alanda parmağını sürükle: kamerayı döndür\nVURUŞ: seçili / yakındaki düşmana sınıfına göre saldır\nYETENEK: sınıfının özel becerisi   ·   KAÇIN: kısa süreli korunma\nİYİLEŞ: 20 mana ile 45 sağlık   ·   TOPLA: kaynak / konuşma\nSINIFLAR: köyde sınıf değiştir   ·   DÜNYA HARİTASI: yol çiz\n\nKurtlar: orman  ·  Demir ve haydutlar: maden  ·  Muhafız: harabe\nBu sürüm tek oyunculu prototiptir; çevrimiçi sunucu henüz yok.",Vector2(24,112),Vector2(710,255),15,Color("c8d0b9"),p)
		button("MACERAYA DEVAM ET",Vector2(24,386),Vector2(510,48),close_modal,p)
		button("SES: AÇIK" if game.sound_on else "SES: KAPALI",Vector2(554,386),Vector2(180,48),func(): game.sound_on=not game.sound_on; show_modal("guide"),p)
