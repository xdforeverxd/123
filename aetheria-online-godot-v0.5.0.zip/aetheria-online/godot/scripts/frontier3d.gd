extends Node3D

var state := FrontierState.new()
var map_data := FrontierMap.new()
var art := FrontierArt.new()
var hud: FrontierHUD
var hero: Node3D
var camera := Camera3D.new()
var camera_yaw := 0.45
var camera_height := 12.0
var camera_distance := 18.0
var stick := Vector2.ZERO
var path: Array[Vector2i] = []
var last_direction := Vector2(0,-1)
var walking := false
var clock := 0.0
var cooldowns := {"attack":0.0,"spin":0.0,"heal":0.0,"dash":0.0}
var dash_left := 0.0
var dash_direction := Vector2.ZERO
var resources: Array[Dictionary] = []
var enemies: Array[Dictionary] = []
var effects: Array[Dictionary] = []
var selected := -1
var target_ring: MeshInstance3D
var npc_position := FrontierMap.NPC
var sound_on := true
var audio := AudioStreamPlayer.new()
var suspended := false
var save_timer := 0.0
var last_combat := -100.0
var orbit_finger := -1
var orbit_start := Vector2.ZERO
var orbit_dragged := false
var mouse_orbit := false

func _ready() -> void:
	get_tree().auto_accept_quit = false
	var loaded := state.load_game()
	add_child(art)
	setup_lighting()
	art.scenery(map_data)
	populate()
	rebuild_hero()
	add_child(camera)
	camera.fov = 57
	camera.far = 180
	camera.current = true
	update_camera(1)
	add_child(audio)
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = FrontierHUD.new()
	hud.game = self
	layer.add_child(hud)
	target_ring = ring_node(1.0,Color(0.95,0.8,0.4,0.24))
	if not loaded: hud.show_modal("classes")
	else: hud.notify("Şafak Limanı'na hoş geldin. Dünya haritasından yol çizebilirsin.")

func setup_lighting() -> void:
	var environment := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color("5a839c")
	sky_material.sky_horizon_color = Color("c2c8ac")
	sky_material.ground_horizon_color = Color("b1b89a")
	sky.sky_material = sky_material
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("d5dfcf")
	env.ambient_light_energy = 0.65
	environment.environment = env
	add_child(environment)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55,-35,0)
	sun.light_color = Color("fff0d2")
	sun.light_energy = 1.1
	sun.shadow_enabled = false
	add_child(sun)

func populate() -> void:
	var npc := art.humanoid(Color("beab73"),"cleric")
	add_child(npc)
	npc.position = FrontierMap.to_world(npc_position)
	art.nameplate(npc,"◆ Tüccar Mira",3.2,Color("f2d69b"))
	for zone in FrontierMap.ZONES:
		var landmark := Node3D.new()
		add_child(landmark)
		landmark.position = FrontierMap.to_world(zone.point)
		art.nameplate(landmark,zone.name,6.3,Color("e9dec1"))
	for p in [Vector2(18,46),Vector2(19,44),Vector2(27,43),Vector2(28,41),Vector2(33,39),Vector2(35,35),Vector2(32,32)]: add_resource(p,"wood")
	for p in [Vector2(45,38),Vector2(46,40),Vector2(48,39),Vector2(50,37),Vector2(46,33),Vector2(43,36)]: add_resource(p,"ore")
	for p in [Vector2(29,40),Vector2(32,39),Vector2(30,33),Vector2(35,36),Vector2(28,44)]: spawn_enemy(p,"wolf")
	for p in [Vector2(47,37),Vector2(50,35),Vector2(46,42)]: spawn_enemy(p,"bandit")
	for p in [Vector2(40,21),Vector2(43,19),Vector2(47,17)]: spawn_enemy(p,"sentinel")
	if not state.boss_defeated: spawn_enemy(Vector2(47,12),"boss")

func add_resource(at: Vector2,kind: String) -> void:
	var position2 := Vector2(map_data.nearest_free(at))
	var n := Node3D.new()
	add_child(n)
	n.position = FrontierMap.to_world(position2)
	if kind=="wood":
		art.mesh(n,art.cone(0.22,1.6,0.19),Vector3(0,0.8,0),Color("7d6745"))
		art.mesh(n,art.cone(1.0,2.7),Vector3(0,2.6,0),Color("4b7954"))
	else:
		art.mesh(n,art.cone(0.8,1.1,0.5),Vector3(0,0.5,0),Color("7d9395"))
		var crystal := art.mesh(n,art.sphere(0.45),Vector3(0.2,1,0.1),Color("99c9d4"))
		crystal.scale = Vector3(0.55,1.8,0.55)
	art.nameplate(n,"Odun" if kind=="wood" else "Demir",3.9 if kind=="wood" else 1.8,Color("d4dfba"))
	resources.append({"position":position2,"kind":kind,"ready":0.0,"node":n})

func spawn_enemy(at: Vector2,kind: String) -> void:
	var p := Vector2(map_data.nearest_free(at))
	var health := 650.0 if kind=="boss" else 110.0 if kind in ["bandit","sentinel"] else 85.0
	var title := {"wolf":"Yaban Kurdu","bandit":"Maden Haydudu","sentinel":"Harabe Nöbetçisi","boss":"Kadim Muhafız"}[kind] as String
	var rig: Node3D = art.guardian() if kind=="boss" else art.wolf() if kind=="wolf" else art.humanoid(Color("927b69") if kind=="bandit" else Color("74848f"),"bandit")
	add_child(rig)
	rig.position = FrontierMap.to_world(p)
	var label := art.nameplate(rig,title,1.9 if kind=="wolf" else 3.0,Color("e2b7a4"))
	if kind=="boss": label.position.y = 3.2
	enemies.append({"position":p,"home":p,"kind":kind,"title":title,"hp":health,"max_hp":health,"node":rig,"label":label,"cooldown":1.0,"windup":0.0,"aim":p,"radius":3.0 if kind=="boss" else 1.5,"respawn":0.0,"slow":0.0,"route":[],"repath":0.0,"warning":null})

func rebuild_hero() -> void:
	if is_instance_valid(hero):
		remove_child(hero)
		hero.queue_free()
	hero = art.humanoid(state.definition().color,state.class_id)
	add_child(hero)
	hero.position = FrontierMap.to_world(state.position)
	art.nameplate(hero,state.definition().name,3.0,Color("f5e8c5"))

func choose_class(id: String) -> void:
	if not FrontierClasses.DATA.has(id): return
	if FrontierMap.zone_at(state.position).id!="haven" or clock-last_combat<6:
		hud.notify("Sınıf değiştirmek için köyde ve savaş dışında olmalısın.")
		return
	state.class_id = id
	state.hp = state.max_hp()
	state.mana = state.max_mana()
	rebuild_hero()
	hud.close_modal()
	hud.notify("%s seçildi. Mira ile konuşarak yolculuğa başla." % state.definition().name)
	persist()

func persist() -> void:
	if not state.save_game() and is_instance_valid(hud): hud.notify("Kayıt yazılamadı; cihazın boş alanını kontrol et.")

func navigate(at: Vector2) -> void:
	path = map_data.route(state.position,at)
	if path.size()>1: path.pop_front()
	if path.is_empty() and is_instance_valid(hud): hud.notify("Buraya ulaşan bir yol bulunamadı.")

func move_actor(from: Vector2,step: Vector2) -> Vector2:
	var p := from
	if map_data.can_stand(p+Vector2(step.x,0)): p.x += step.x
	if map_data.can_stand(p+Vector2(0,step.y)): p.y += step.y
	return p

func _process(delta: float) -> void:
	if not is_instance_valid(hud): return
	if suspended or not hud.modal_mode.is_empty():
		walking = false
		return
	var dt := minf(delta,0.05)
	clock += dt
	for key in cooldowns: cooldowns[key] = maxf(0,float(cooldowns[key])-dt)
	dash_left = maxf(0,dash_left-dt)
	state.mana = minf(state.max_mana(),state.mana+dt*4.0)
	var input := stick
	if Input.is_physical_key_pressed(KEY_W): input.y -= 1
	if Input.is_physical_key_pressed(KEY_S): input.y += 1
	if Input.is_physical_key_pressed(KEY_A): input.x -= 1
	if Input.is_physical_key_pressed(KEY_D): input.x += 1
	var direction := Vector2.ZERO
	if input.length()>0.12:
		path.clear()
		direction = input.rotated(-camera_yaw).normalized()
	elif not path.is_empty():
		direction = Vector2(path[0])-state.position
		if direction.length()<0.16:
			path.pop_front()
			direction = Vector2.ZERO
		else: direction = direction.normalized()
	if dash_left>0: direction = dash_direction
	var previous := state.position
	state.position = move_actor(state.position,direction*dt*(10.0 if dash_left>0 else 2.8))
	walking = previous.distance_to(state.position)>0.001
	if walking:
		last_direction = direction
		hero.rotation.y = lerp_angle(hero.rotation.y,atan2(direction.x,direction.y),dt*12)
	hero.position = FrontierMap.to_world(state.position)
	art.animate_rig(hero,clock,walking,maxf(0,cooldowns.attack-float(state.definition().cooldown)+0.35)/0.35)
	update_enemies(dt)
	update_effects(dt)
	update_camera(dt)
	var target := selected_target()
	target_ring.visible = not target.is_empty()
	if not target.is_empty(): target_ring.position = FrontierMap.to_world(target.position,0.06)
	var zone := FrontierMap.zone_at(state.position)
	if zone.id not in state.discovered:
		state.discovered.append(zone.id)
		hud.notify("Yeni bölge: "+zone.name+" · "+zone.level)
		state.add_xp(20)
		persist()
	for r in resources: r.node.visible = r.ready<=clock
	save_timer += dt
	if save_timer>3:
		persist()
		save_timer = 0

func update_camera(dt: float) -> void:
	var center := FrontierMap.to_world(state.position,1.3)
	var desired := center+Vector3(sin(camera_yaw)*camera_distance,camera_height,cos(camera_yaw)*camera_distance)
	camera.position = desired if dt>=1 else camera.position.lerp(desired,minf(1,dt*8))
	camera.look_at(center)

func selected_target() -> Dictionary:
	if selected>=0 and selected<enemies.size() and enemies[selected].hp>0 and state.position.distance_to(enemies[selected].position)<13:
		return enemies[selected]
	var best := 10.0
	selected = -1
	for i in enemies.size():
		var d: float = state.position.distance_to(enemies[i].position)
		if enemies[i].hp>0 and d<best:
			best = d
			selected = i
	return enemies[selected] if selected>=0 else {}

func update_enemies(dt: float) -> void:
	for e in enemies:
		if e.hp<=0:
			if e.kind!="boss" and e.respawn<=clock:
				e.hp = e.max_hp
				e.position = e.home
				e.node.visible = true
			continue
		e.cooldown = maxf(0,e.cooldown-dt)
		e.slow = maxf(0,e.slow-dt)
		if e.windup>0:
			e.windup = maxf(0,e.windup-dt)
			if e.windup<=0:
				if is_instance_valid(e.warning): e.warning.queue_free()
				e.warning = null
				if state.position.distance_to(e.aim)<e.radius and dash_left<=0:
					var damage := (30 if e.kind=="boss" else 15 if e.kind!="wolf" else 11)
					if state.class_id=="guardian": damage = roundi(damage*0.75)
					state.hp -= damage
					last_combat = clock
					floating(state.position,"−%d" % damage,Color("f1a38a"))
					if state.hp<=0:
						respawn()
						return
			continue
		var d: float = e.position.distance_to(state.position)
		var safe: bool = FrontierMap.zone_at(state.position).id=="haven"
		var destination: Vector2 = state.position if d<9 and not safe and state.position.distance_to(e.home)<12 else e.home
		var moving := false
		if (destination==state.position and d>(2.2 if e.kind=="boss" else 1.3)) or (destination==e.home and e.position.distance_to(e.home)>0.2):
			e.repath -= dt
			if e.repath<=0:
				e.route = map_data.route(e.position,destination)
				if e.route.size()>1: e.route.pop_front()
				e.repath = 0.8
			if not e.route.is_empty():
				var direction: Vector2 = Vector2(e.route[0])-e.position
				if direction.length()<0.2: e.route.pop_front()
				else:
					var speed := 1.0 if e.kind=="boss" else 1.7
					if e.slow>0: speed *= 0.4
					e.position = move_actor(e.position,direction.normalized()*dt*speed)
					e.node.rotation.y = lerp_angle(e.node.rotation.y,atan2(direction.x,direction.y),dt*8)
					moving = true
		elif destination==state.position and e.cooldown<=0:
			e.aim = state.position
			e.windup = 1.2 if e.kind=="boss" else 0.7
			e.cooldown = 2.8 if e.kind=="boss" else 2.1
			e.warning = ring_node(e.radius*FrontierMap.SCALE,Color(0.85,0.25,0.15,0.45))
			e.warning.position = FrontierMap.to_world(e.aim,0.07)
		e.node.position = FrontierMap.to_world(e.position)
		art.animate_rig(e.node,clock,moving,0)
		e.label.text = e.title+"\n%d / %d" % [ceili(e.hp),int(e.max_hp)]

func respawn() -> void:
	state.position = FrontierMap.SPAWN
	state.hp = state.max_hp()
	state.mana = state.max_mana()
	path.clear()
	dash_left = 0
	selected = -1
	for e in enemies:
		e.position = e.home
		e.windup = 0
		e.cooldown = 1.5
		if is_instance_valid(e.warning): e.warning.queue_free()
		e.warning = null
	hud.notify("Şafak Limanı'nda yeniden doğdun. Eşyaların korunuyor.")
	update_camera(1)
	persist()

func nearest_resource() -> Dictionary:
	var best := 1.9
	var nearest: Dictionary = {}
	for r in resources:
		var d: float = state.position.distance_to(r.position)
		if r.ready<=clock and d<best:
			best = d
			nearest = r
	return nearest

func action(name: String) -> void:
	if suspended or not hud.modal_mode.is_empty(): return
	if name=="bag":
		hud.show_modal("inventory")
		return
	if name=="interact":
		if state.position.distance_to(npc_position)<2:
			state.visited = true
			hud.notify("Mira: Köprüden ormana geç. Demir için doğudaki madene git. Harabeye hazırlıklı çık!")
		else:
			var r := nearest_resource()
			if r.is_empty():
				hud.notify("Kaynağa veya Mira'ya yaklaş.")
				return
			r.ready = clock+40
			if r.kind=="wood": state.wood += 1
			else: state.ore += 1
			state.gathered += 1
			grant_xp(12)
			floating(r.position,"+1 Odun" if r.kind=="wood" else "+1 Demir",Color("e7d3a1"))
		persist()
		return
	if cooldowns.get(name,0)>0: return
	if name=="dash":
		dash_direction = last_direction
		dash_left = 0.3
		cooldowns.dash = 3.2
	elif name=="heal":
		if state.mana<20 or state.hp>=state.max_hp():
			hud.notify("Sağlığın tam veya 20 manan yok.")
			return
		state.mana -= 20
		state.hp = minf(state.max_hp(),state.hp+45)
		cooldowns.heal = 10
		floating(state.position,"+45",Color("bfdba3"))
	elif name=="attack" or name=="spin":
		var definition := state.definition()
		var target := selected_target()
		var special := name=="spin"
		if special and state.mana<definition.skill_cost:
			hud.notify("Yetenek için yeterli mana yok.")
			return
		if special and state.class_id=="cleric":
			state.mana -= definition.skill_cost
			cooldowns.spin = definition.skill_cd
			state.hp = minf(state.max_hp(),state.hp+55)
			floating(state.position,"+55",Color("dfdfb2"))
			for e in enemies:
				if e.hp>0 and e.position.distance_to(state.position)<4: damage_enemy(e,23)
			burst(state.position,Color("e5dba5"),4)
		else:
			if target.is_empty() or state.position.distance_to(target.position)>definition.range:
				hud.notify("Hedefe yaklaş. Menzilin: %d metre." % int(definition.range*2))
				return
			last_combat = clock
			if special:
				state.mana -= definition.skill_cost
				cooldowns.spin = definition.skill_cd
				var center: Vector2 = state.position if state.class_id=="guardian" else target.position
				for e in enemies:
					if e.hp>0 and e.position.distance_to(center)<(3.0 if state.class_id=="guardian" else 3.5):
						damage_enemy(e,state.attack_damage()+(32 if state.class_id=="mage" else 14))
						e.slow = 2.5
				burst(center,definition.color,3)
			else:
				cooldowns.attack = definition.cooldown
				damage_enemy(target,state.attack_damage())
				if state.class_id!="guardian": projectile(state.position,target.position,definition.color)
				else: burst(state.position,Color("e7d2aa"),1.5)
			hero.rotation.y = atan2(target.position.x-state.position.x,target.position.y-state.position.y)
	tone(380 if name=="attack" else 560)
	persist()

func damage_enemy(e: Dictionary,damage: int) -> void:
	e.hp = maxf(0,e.hp-damage)
	floating(e.position,str(damage),Color("f0d1a2"))
	if e.hp<=0:
		e.node.visible = false
		e.respawn = clock+45
		e.windup = 0
		if is_instance_valid(e.warning): e.warning.queue_free()
		e.warning = null
		if e.kind=="boss":
			state.boss_defeated = true
			state.gold += 100
			grant_xp(180)
			hud.notify("Kadim Muhafız yenildi! Şafak Limanı güvende. Görev ödüllerini al.")
		elif e.kind=="wolf":
			state.kills += 1
			state.gold += 8
			grant_xp(25)
		else:
			if e.kind=="bandit": state.bandit_kills += 1
			state.gold += 15
			grant_xp(35)
		persist()

func sell_wood() -> void:
	if state.position.distance_to(npc_position)<2 and state.wood>=3:
		state.wood -= 3
		state.gold += 12
		hud.notify("3 odun satıldı. +12 altın.")
		persist()

func grant_xp(amount: int) -> void:
	if state.add_xp(amount): hud.notify("Seviye %d! Sağlığın yenilendi." % state.level)

func ring_node(radius: float,color: Color) -> MeshInstance3D:
	return art.mesh(self,art.cone(radius,0.025,radius),Vector3.ZERO,color)

func burst(at: Vector2,color: Color,radius: float) -> void:
	var n := ring_node(radius*2,Color(color,0.35))
	n.position = FrontierMap.to_world(at,0.08)
	effects.append({"node":n,"start":clock,"life":0.45,"kind":"ring","position":n.position})

func floating(at: Vector2,text: String,color: Color) -> void:
	var n := Label3D.new()
	n.text = text
	n.font_size = 46
	n.pixel_size = 0.012
	n.modulate = color
	n.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	n.position = FrontierMap.to_world(at,3)
	add_child(n)
	effects.append({"node":n,"start":clock,"life":0.85,"kind":"text","position":n.position})

func projectile(from: Vector2,to: Vector2,color: Color) -> void:
	var n := art.mesh(self,art.sphere(0.18),FrontierMap.to_world(from,1.5),color.lightened(0.3))
	effects.append({"node":n,"start":clock,"life":0.25,"kind":"projectile","position":n.position,"to":FrontierMap.to_world(to,1.3)})

func update_effects(_dt: float) -> void:
	for e in effects:
		var t: float = (clock-e.start)/e.life
		if t>=1: e.node.queue_free()
		elif e.kind=="text": e.node.position = e.position+Vector3(0,t*1.8,0)
		elif e.kind=="projectile": e.node.position = e.position.lerp(e.to,t)
		else: e.node.scale = Vector3.ONE*(0.15+t*0.85)
	effects = effects.filter(func(e: Dictionary) -> bool: return clock-e.start<e.life)

func tone(frequency: float) -> void:
	if not sound_on: return
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = 22050
	var samples := PackedByteArray()
	samples.resize(4410)
	for i in 2205: samples.encode_s16(i*2,int(sin(TAU*frequency*i/22050)*1600*(1.0-i/2205.0)))
	stream.data = samples
	audio.stream = stream
	audio.play()

func _notification(what: int) -> void:
	if what in [NOTIFICATION_APPLICATION_PAUSED,NOTIFICATION_APPLICATION_FOCUS_OUT]:
		suspended = true
		stick = Vector2.ZERO
		orbit_finger = -1
		persist()
	elif what in [NOTIFICATION_APPLICATION_RESUMED,NOTIFICATION_APPLICATION_FOCUS_IN]: suspended = false
	elif what in [NOTIFICATION_WM_GO_BACK_REQUEST,NOTIFICATION_WM_CLOSE_REQUEST] and is_instance_valid(hud):
		if hud.modal_mode.is_empty(): hud.show_modal("exit")
		else: hud.close_modal()

func _input(event: InputEvent) -> void:
	if not is_instance_valid(hud): return
	if event is InputEventScreenTouch:
		if event.pressed and hud.handle_touch(event.position):
			get_viewport().set_input_as_handled()
			return
		if not hud.modal_mode.is_empty(): return
		if event.pressed and hud.joystick_pointer==-1 and event.position.distance_to(hud.joystick_center)<85:
			hud.joystick_pointer = event.index
			set_stick(event.position)
			get_viewport().set_input_as_handled()
		elif not event.pressed and event.index==hud.joystick_pointer:
			hud.joystick_pointer = -1
			stick = Vector2.ZERO
			hud.joystick_offset = Vector2.ZERO
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and event.index==hud.joystick_pointer:
		set_stick(event.position)
		get_viewport().set_input_as_handled()
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_SPACE,KEY_1: action("attack")
			KEY_2: action("spin")
			KEY_3: action("heal")
			KEY_4: action("dash")
			KEY_E: action("interact")
			KEY_I: action("bag")
			KEY_M: hud.show_modal("map")

func set_stick(at: Vector2) -> void:
	hud.joystick_offset = (at-hud.joystick_center).limit_length(38)
	stick = hud.joystick_offset/38
	path.clear()

func ground_point(screen: Vector2) -> Vector2:
	var from := camera.project_ray_origin(screen)
	var ray := camera.project_ray_normal(screen)
	if absf(ray.y)<0.001: return state.position
	var at := from+ray*(-from.y/ray.y)
	return Vector2(at.x,at.z)/FrontierMap.SCALE

func world_tap(screen: Vector2) -> void:
	var at := ground_point(screen)
	for i in enemies.size():
		if enemies[i].hp>0 and enemies[i].position.distance_to(at)<1.2:
			selected = i
			if state.position.distance_to(at)>state.definition().range: navigate(at)
			return
	navigate(at)

func _unhandled_input(event: InputEvent) -> void:
	if suspended or not hud.modal_mode.is_empty(): return
	if event is InputEventScreenTouch:
		if event.pressed and orbit_finger==-1:
			orbit_finger = event.index
			orbit_start = event.position
			orbit_dragged = false
		elif not event.pressed and event.index==orbit_finger:
			if not orbit_dragged: world_tap(event.position)
			orbit_finger = -1
	elif event is InputEventScreenDrag and event.index==orbit_finger:
		if event.position.distance_to(orbit_start)>12: orbit_dragged = true
		if orbit_dragged:
			camera_yaw -= event.relative.x*0.006
			camera_height = clampf(camera_height+event.relative.y*0.04,7,22)
	elif event is InputEventMouseButton:
		if event.button_index==MOUSE_BUTTON_RIGHT: mouse_orbit = event.pressed
		elif event.button_index==MOUSE_BUTTON_LEFT and event.pressed: world_tap(event.position)
		elif event.button_index==MOUSE_BUTTON_WHEEL_UP: camera_distance = maxf(10,camera_distance-1)
		elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN: camera_distance = minf(28,camera_distance+1)
	elif event is InputEventMouseMotion and mouse_orbit:
		camera_yaw -= event.relative.x*0.006
		camera_height = clampf(camera_height+event.relative.y*0.04,7,22)

func _exit_tree() -> void:
	if is_instance_valid(audio):
		audio.stop()
		audio.stream = null
