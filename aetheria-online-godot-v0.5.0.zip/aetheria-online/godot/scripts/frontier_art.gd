class_name FrontierArt
extends Node3D

var materials: Dictionary = {}

func material(color: Color) -> StandardMaterial3D:
	var key := color.to_html()
	if materials.has(key): return materials[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.95
	if color.a<1:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	materials[key] = m
	return m

func mesh(parent: Node3D, shape: Mesh, at: Vector3, color: Color) -> MeshInstance3D:
	var n := MeshInstance3D.new()
	n.mesh = shape
	n.material_override = material(color)
	n.position = at
	n.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(n)
	return n

func box(parent: Node3D, at: Vector3, dimensions: Vector3, color: Color) -> MeshInstance3D:
	var m := BoxMesh.new()
	m.size = dimensions
	return mesh(parent,m,at,color)

func cone(radius: float,height: float,top:=0.0) -> CylinderMesh:
	var m := CylinderMesh.new()
	m.top_radius = top
	m.bottom_radius = radius
	m.height = height
	m.radial_segments = 7
	return m

func sphere(radius: float) -> SphereMesh:
	var m := SphereMesh.new()
	m.radius = radius
	m.height = radius*2
	m.radial_segments = 10
	m.rings = 5
	return m

func ground() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for y in FrontierMap.SIZE:
		for x in FrontierMap.SIZE:
			var p := Vector2(x,y)
			var color: Color = FrontierMap.zone_at(p).color
			var kind := FrontierMap.terrain(Vector2i(x,y))
			if kind=="water": color = Color("437e91")
			elif kind=="road": color = Color("b6a77d")
			elif kind=="bridge": color = Color("866844")
			elif kind=="edge": color = Color("536b58")
			color = color.lightened(FrontierMap.random_at(x,y)*0.08)
			var center := FrontierMap.to_world(p)
			var corners := [center+Vector3(-1,0,-1),center+Vector3(1,0,-1),center+Vector3(1,0,1),center+Vector3(-1,0,1)]
			for index in [0,2,1,0,3,2]:
				st.set_color(color)
				st.set_normal(Vector3.UP)
				st.add_vertex(corners[index])
	var instance := MeshInstance3D.new()
	instance.mesh = st.commit()
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1
	instance.material_override = mat
	add_child(instance)

func batch(shape: Mesh, points: Array[Vector3], color: Color) -> void:
	if points.is_empty(): return
	var multimesh := MultiMesh.new()
	multimesh.transform_format = MultiMesh.TRANSFORM_3D
	multimesh.mesh = shape
	multimesh.instance_count = points.size()
	for i in points.size(): multimesh.set_instance_transform(i,Transform3D(Basis.IDENTITY,points[i]))
	var instance := MultiMeshInstance3D.new()
	instance.multimesh = multimesh
	instance.material_override = material(color)
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)

func scenery(map: FrontierMap) -> void:
	ground()
	var trunks: Array[Vector3] = []
	var foliage: Array[Vector3] = []
	var rocks: Array[Vector3] = []
	for cell in map.solids:
		var point := FrontierMap.to_world(Vector2(cell))
		if map.solids[cell]=="tree":
			trunks.append(point+Vector3(0,1.0,0))
			foliage.append(point+Vector3(0,3.0,0))
		elif map.solids[cell]=="rock": rocks.append(point+Vector3(0,0.8,0))
	batch(cone(0.18,2.0,0.15),trunks,Color("705d42"))
	batch(cone(1.25,3.6),foliage,Color("315e49"))
	var tops: Array[Vector3] = []
	for p in foliage: tops.append(p+Vector3(0,1.4,0))
	batch(cone(0.9,2.4),tops,Color("4f7951"))
	batch(cone(1.15,1.8,0.65),rocks,Color("7e8987"))
	for cell in FrontierMap.HOUSES: house(FrontierMap.to_world(Vector2(cell)))
	# A readable bridge, road lanterns and a mill establish landmarks.
	for y in range(39,44):
		for x in range(19,26):
			if FrontierMap.terrain(Vector2i(x,y))=="bridge":
				box(self,FrontierMap.to_world(Vector2(x,y),0.08),Vector3(1.95,0.16,1.95),Color("92754e"))
	for p in [Vector2(13,47),Vector2(18,44),Vector2(27,39),Vector2(36,34),Vector2(43,18)]:
		var at := FrontierMap.to_world(p)
		mesh(self,cone(0.09,2.7,0.08),at+Vector3(0,1.35,0),Color("625b46"))
		mesh(self,sphere(0.23),at+Vector3(0,2.8,0),Color("f2d19a"))
	ruins()
	mill(FrontierMap.to_world(Vector2(16,32)))
	for i in 12:
		var p := Vector3(4+i*11,2.4,2)
		mesh(self,cone(7,7,0),p,Color("6f8070"))
	# Mine supports and crystal deposits distinguish the eastern region.
	for p in [Vector2(49,36),Vector2(48,41),Vector2(53,35)]:
		var at := FrontierMap.to_world(p)
		box(self,at+Vector3(-1.4,1.6,0),Vector3(0.35,3.2,0.4),Color("64543d"))
		box(self,at+Vector3(1.4,1.6,0),Vector3(0.35,3.2,0.4),Color("64543d"))
		box(self,at+Vector3(0,3.1,0),Vector3(3.3,0.45,0.4),Color("806448"))

func house(at: Vector3) -> void:
	var building := Node3D.new()
	add_child(building)
	building.position = at
	box(building,Vector3(0,1.75,0),Vector3(5.3,3.5,5.3),Color("b4a68a"))
	var roof := PrismMesh.new()
	roof.size = Vector3(6.5,2.8,6.5)
	mesh(building,roof,Vector3(0,4.85,0),Color("83604c"))
	box(building,Vector3(0,1,2.68),Vector3(1.1,2,0.1),Color("514c42"))
	for x in [-1.7,1.7]: box(building,Vector3(x,2.3,2.69),Vector3(0.65,0.8,0.12),Color("ecc98b"))
	for x in [-2.6,2.6]: box(building,Vector3(x,1.75,2.7),Vector3(0.14,3.5,0.15),Color("78634a"))
	box(building,Vector3(1.4,5.3,-1.2),Vector3(0.65,2,0.65),Color("7d7c70"))

func ruins() -> void:
	var gate := FrontierMap.to_world(Vector2(44,18))
	for offset in [-4.0,4.0]:
		mesh(self,cone(0.75,6,0.65),gate+Vector3(offset,3,0),Color("8a9c9d"))
		box(self,gate+Vector3(offset,0.4,0),Vector3(2.2,0.8,2.2),Color("6d8587"))
	box(self,gate+Vector3(0,6.1,0),Vector3(10,1,1.5),Color("a8b0a4"))
	for p in [Vector2(39,14),Vector2(42,10),Vector2(50,12),Vector2(49,17)]:
		var at := FrontierMap.to_world(p)
		mesh(self,cone(0.65,4,0.6),at+Vector3(0,2,0),Color("819999"))
	var center := FrontierMap.to_world(Vector2(47,12),0.12)
	mesh(self,cone(5.0,0.2,5.0),center,Color("708c92"))
	mesh(self,sphere(0.9),center+Vector3(0,4,0),Color("a3b3d5"))

func mill(at: Vector3) -> void:
	mesh(self,cone(1.6,6,1.1),at+Vector3(0,3,0),Color("b9af90"))
	mesh(self,cone(2,2.3),at+Vector3(0,7,0),Color("807052"))
	var sails := Node3D.new()
	add_child(sails)
	sails.position = at+Vector3(0,5,1.65)
	sails.name = "MillSails"
	for angle in [0.0,PI/2]:
		var blade := box(sails,Vector3.ZERO,Vector3(0.25,7,0.15),Color("d6cda5"))
		blade.rotation.z = angle

func humanoid(color: Color, kind: String) -> Node3D:
	var rig := Node3D.new()
	mesh(rig,cone(0.1,0.02,0.1),Vector3.ZERO,Color(0,0,0,0.2))
	box(rig,Vector3(0,1.25,0),Vector3(0.75,0.8,0.45),color)
	var cape := box(rig,Vector3(0,1.2,-0.31),Vector3(0.9,1.1,0.08),color.darkened(0.2))
	cape.rotation.x = -0.16
	mesh(rig,sphere(0.27),Vector3(0,1.98,0),Color("d5b68f"))
	for x in [-0.1,0.1]: box(rig,Vector3(x,2.01,0.25),Vector3(0.055,0.055,0.04),Color("374345"))
	for side in [-1,1]:
		var leg := Node3D.new()
		rig.add_child(leg)
		leg.name = "LeftLeg" if side<0 else "RightLeg"
		leg.position = Vector3(side*0.22,0.9,0)
		box(leg,Vector3(0,-0.4,0),Vector3(0.25,0.8,0.28),Color("4c5b55"))
		box(leg,Vector3(0,-0.77,0.1),Vector3(0.3,0.18,0.45),Color("495046"))
		var arm := Node3D.new()
		rig.add_child(arm)
		arm.name = "LeftArm" if side<0 else "RightArm"
		arm.position = Vector3(side*0.55,1.6,0)
		box(arm,Vector3(0,-0.3,0),Vector3(0.25,0.6,0.25),color.lightened(0.1))
		mesh(arm,sphere(0.14),Vector3(0,-0.65,0),Color("d5b68f"))
	var right: Node3D = rig.get_node("RightArm")
	if kind=="guardian" or kind=="bandit":
		box(right,Vector3(0,-1.0,0.2),Vector3(0.12,1.0,0.08),Color("dce2d4"))
		box(right,Vector3(0,-0.6,0.2),Vector3(0.46,0.1,0.1),Color("cfb16d"))
		var shield := mesh(rig.get_node("LeftArm"),cone(0.43,0.12,0.43),Vector3(-0.1,-0.45,0.2),color.lightened(0.15))
		shield.rotation.x = PI/2
		mesh(rig,cone(0.3,0.38,0.2),Vector3(0,2.18,0),Color("b6c3b7"))
	elif kind=="ranger":
		box(right,Vector3(0,-0.45,0.25),Vector3(0.09,1.2,0.09),Color("a18556"))
		box(right,Vector3(0,-0.45,0.33),Vector3(0.03,1.1,0.03),Color("d9d6b8"))
		mesh(rig,cone(0.4,0.45),Vector3(0,2.2,0),color.darkened(0.1))
	else:
		box(right,Vector3(0,-0.2,0.25),Vector3(0.1,1.85,0.1),Color("9e8d67"))
		mesh(right,sphere(0.24),Vector3(0,0.8,0.25),Color("d5cfa2") if kind=="cleric" else Color("aea2dc"))
		mesh(rig,cone(0.43,0.7),Vector3(0,2.4,0),color)
	return rig

func wolf() -> Node3D:
	var rig := Node3D.new()
	box(rig,Vector3(0,0.7,0),Vector3(0.65,0.55,1.25),Color("8c9c93"))
	mesh(rig,sphere(0.36),Vector3(0,0.95,0.7),Color("a4b1a1"))
	box(rig,Vector3(0,0.88,1.02),Vector3(0.35,0.25,0.4),Color("76897c"))
	for x in [-0.24,0.24]:
		mesh(rig,cone(0.13,0.35),Vector3(x,1.3,0.66),Color("607b68"))
		for z in [-0.4,0.4]: box(rig,Vector3(x,0.3,z),Vector3(0.14,0.6,0.16),Color("657d6d"))
	return rig

func guardian() -> Node3D:
	var rig := humanoid(Color("7b9297"),"guardian")
	rig.scale = Vector3.ONE*2.4
	return rig

func nameplate(parent: Node3D, text: String, height: float, color: Color) -> Label3D:
	var label := Label3D.new()
	label.text = text
	label.font_size = 36
	label.pixel_size = 0.008
	label.outline_size = 7
	label.modulate = color
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = false
	label.position.y = height
	parent.add_child(label)
	return label

func animate_rig(rig: Node3D,time: float,moving: bool,swing: float) -> void:
	if rig.has_node("LeftLeg"):
		var step := sin(time*11)*0.6 if moving else 0.0
		rig.get_node("LeftLeg").rotation.x = step
		rig.get_node("RightLeg").rotation.x = -step
		rig.get_node("LeftArm").rotation.x = -step*0.5
		rig.get_node("RightArm").rotation.x = -1.5*swing+step*0.5
		if rig.has_node("RightArm"): rig.get_node("RightArm").rotation.z = sin(swing*PI)*-0.65
