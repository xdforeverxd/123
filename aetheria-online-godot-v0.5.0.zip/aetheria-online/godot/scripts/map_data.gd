class_name FrontierMap
extends RefCounted

const SIZE := 64
const SCALE := 2.0
const SPAWN := Vector2(13,49)
const NPC := Vector2(14,46)
const ZONES := [
	{"id":"haven","name":"Şafak Limanı","level":"1 · Güvenli bölge","rect":Rect2(3,40,19,20),"point":Vector2(13,49),"color":Color("829365")},
	{"id":"meadow","name":"Yel Değirmeni Ovası","level":"1–2 · Kaynaklar","rect":Rect2(3,21,18,19),"point":Vector2(15,35),"color":Color("81985c")},
	{"id":"forest","name":"Fısıltılı Orman","level":"2–3 · Yaban kurtları","rect":Rect2(24,26,18,30),"point":Vector2(30,38),"color":Color("416b49")},
	{"id":"mine","name":"Bakırtaş Madeni","level":"3–4 · Haydutlar","rect":Rect2(42,27,18,30),"point":Vector2(47,38),"color":Color("8b8270")},
	{"id":"ruins","name":"Aether Harabeleri","level":"4–5 · Kadim Muhafız","rect":Rect2(33,3,28,23),"point":Vector2(46,15),"color":Color("727d83")}
]
const ROADS := [
	[Vector2(13,49),Vector2(18,44),Vector2(25,40),Vector2(30,38),Vector2(36,34),Vector2(44,34),Vector2(47,38)],
	[Vector2(30,38),Vector2(32,29),Vector2(37,22),Vector2(43,18),Vector2(47,13)],
	[Vector2(13,49),Vector2(12,42),Vector2(15,35),Vector2(17,31)]
]
const HOUSES := [Vector2i(8,46),Vector2i(17,49),Vector2i(9,53),Vector2i(17,54),Vector2i(11,41)]
var grid := AStarGrid2D.new()
var solids: Dictionary = {}

static func random_at(x: float,y: float) -> float:
	return fposmod(sin(x*127.1+y*311.7)*43758.5453,1.0)

static func zone_at(p: Vector2) -> Dictionary:
	for zone in ZONES:
		if zone.rect.has_point(p): return zone
	return ZONES[1]

static func road_distance(p: Vector2) -> float:
	var closest := 1000.0
	for road in ROADS:
		for i in range(road.size()-1):
			closest = minf(closest,p.distance_to(Geometry2D.get_closest_point_to_segment(p,road[i],road[i+1])))
	return closest

static func terrain(p: Vector2i) -> String:
	if p.x<2 or p.y<2 or p.x>61 or p.y>61: return "edge"
	var river := absf(p.x-(22.5+sin(p.y*0.18)*2.3))<1.25 and p.y>10
	if river:
		return "bridge" if road_distance(Vector2(p))<1.3 else "water"
	if Vector2(p-Vector2i(11,29)).length()<3.5 or Vector2(p-Vector2i(54,46)).length()<3:
		return "water"
	if road_distance(Vector2(p))<1.05: return "road"
	return "grass"

static func obstruction(p: Vector2i) -> String:
	if terrain(p) in ["edge","water"]: return "water"
	for house in HOUSES:
		if absi(p.x-house.x)<=1 and absi(p.y-house.y)<=1: return "house"
	if road_distance(Vector2(p))<2.2 or Vector2(p).distance_to(NPC)<2: return ""
	var zone := zone_at(Vector2(p)).id as String
	var n := random_at(p.x,p.y)
	if zone=="forest" and n>0.94: return "tree"
	if zone=="meadow" and n>0.982: return "tree"
	if zone=="mine" and n>0.965: return "rock"
	if zone=="ruins" and n>0.98: return "rock"
	return ""

func _init() -> void:
	grid.region = Rect2i(0,0,SIZE,SIZE)
	grid.cell_size = Vector2.ONE
	grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	grid.default_compute_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	grid.default_estimate_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	grid.update()
	for y in SIZE:
		for x in SIZE:
			var p := Vector2i(x,y)
			var obstacle := obstruction(p)
			if not obstacle.is_empty():
				solids[p] = obstacle
				grid.set_point_solid(p,true)
			elif terrain(p)=="road" or terrain(p)=="bridge":
				grid.set_point_weight_scale(p,0.8)

func walkable(p: Vector2) -> bool:
	var cell := Vector2i(roundi(p.x),roundi(p.y))
	return grid.is_in_boundsv(cell) and not grid.is_point_solid(cell)

func can_stand(p: Vector2) -> bool:
	for offset in [Vector2(-0.22,-0.22),Vector2(0.22,-0.22),Vector2(-0.22,0.22),Vector2(0.22,0.22)]:
		if not walkable(p+offset): return false
	return true

func nearest_free(p: Vector2) -> Vector2i:
	var cell := Vector2i(clampi(roundi(p.x),2,61),clampi(roundi(p.y),2,61))
	if walkable(Vector2(cell)): return cell
	for radius in range(1,6):
		for y in range(-radius,radius+1):
			for x in range(-radius,radius+1):
				var candidate := cell+Vector2i(x,y)
				if walkable(Vector2(candidate)): return candidate
	return Vector2i(SPAWN)

func route(from: Vector2,to: Vector2) -> Array[Vector2i]:
	return grid.get_id_path(nearest_free(from),nearest_free(to))

static func to_world(p: Vector2,height:=0.0) -> Vector3:
	return Vector3(p.x*SCALE,height,p.y*SCALE)
