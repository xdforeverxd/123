class_name FrontierClasses
extends RefCounted

const DATA := {
	"guardian": {"name":"Muhafız","role":"Tank / yakın dövüş","hp":160.0,"mana":75.0,"damage":27,"range":2.0,"cooldown":0.75,"skill":"Kalkan Darbesi","skill_cost":16.0,"skill_cd":7.0,"color":Color("537d9a"),"description":"Yüksek sağlık. Kılıç ve kalkanla yakın çatışma. Alan darbesi düşmanları sersemletir."},
	"ranger": {"name":"Avcı","role":"Uzak menzilli hasar","hp":115.0,"mana":85.0,"damage":23,"range":8.0,"cooldown":0.7,"skill":"Ok Yağmuru","skill_cost":18.0,"skill_cd":6.0,"color":Color("638854"),"description":"Uzaktan ok atar. Ok Yağmuru hedef çevresine hasar verir ve düşmanları yavaşlatır."},
	"mage": {"name":"Aether Büyücüsü","role":"Büyü / alan hasarı","hp":100.0,"mana":125.0,"damage":26,"range":7.0,"cooldown":0.9,"skill":"Aether Patlaması","skill_cost":26.0,"skill_cd":8.0,"color":Color("8574b0"),"description":"Yüksek mana, düşük dayanıklılık. Aether Patlaması hedef çevresindeki düşmanları vurur."},
	"cleric": {"name":"Işık Rahibi","role":"İyileştirme / destek","hp":125.0,"mana":135.0,"damage":19,"range":6.5,"cooldown":0.85,"skill":"Kutsal Alan","skill_cost":24.0,"skill_cd":9.0,"color":Color("ceb477"),"description":"Işık saldırıları kullanır. Kutsal Alan kendini iyileştirir ve yakındaki düşmanları vurur."}
}

static func definition(id: String) -> Dictionary:
	return DATA.get(id,DATA.guardian)
