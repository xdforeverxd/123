class_name FrontierState
extends AetheriaState

const RPG_SAVE := "user://frontier3d_v1.json"
var class_id := "guardian"
var bandit_kills := 0
var discovered: Array[String] = ["haven"]

func _init() -> void:
	position = FrontierMap.SPAWN
	hp = max_hp()
	mana = max_mana()

func definition() -> Dictionary:
	return FrontierClasses.definition(class_id)

func max_hp() -> float:
	return float(definition().hp)+(level-1)*18.0

func max_mana() -> float:
	return float(definition().mana)

func attack_damage() -> int:
	return int(definition().damage)+(weapon-1)*8+(level-1)*3

func objectives() -> Array[Dictionary]:
	return [
		{"title":"Mira ile tanış","done":visited,"progress":"1/1" if visited else "0/1","hint":"Köy meydanında altın işaretli Mira ile konuş."},
		{"title":"Ormanın kurtları","done":kills>=3,"progress":"%d/3" % mini(kills,3),"hint":"Köprüden doğuya geç. Ormanda 3 kurt yen."},
		{"title":"Ustalık malzemeleri","done":gathered>=8,"progress":"%d/8" % mini(gathered,8),"hint":"Ormandan odun, madenden demir topla."},
		{"title":"Bakırtaş yolculuğu","done":"mine" in discovered,"progress":"1/1" if "mine" in discovered else "0/1","hint":"Haritadan Bakırtaş Madeni'ne yol çiz."},
		{"title":"Silahını güçlendir","done":weapon>=2,"progress":"1/1" if weapon>=2 else "0/1","hint":"5 odun + 3 demirle çantadan silah geliştir."},
		{"title":"Haydut tehlikesi","done":bandit_kills>=3,"progress":"%d/3" % mini(bandit_kills,3),"hint":"Maden bölgesindeki 3 haydudu yen."},
		{"title":"Kadim Muhafız","done":boss_defeated,"progress":"1/1" if boss_defeated else "0/1","hint":"Kuzeydoğudaki harabede muhafızı yen."}
	]

func claim(index: int) -> bool:
	if index<0 or index>=objectives().size() or index in rewarded or not objectives()[index].done: return false
	rewarded.append(index)
	gold += 100 if index==6 else 30
	add_xp(150 if index==6 else 45)
	return true

func data() -> Dictionary:
	var d := super.data()
	d.schema = 2
	d.class_id = class_id
	d.bandit_kills = bandit_kills
	d.discovered = discovered
	return d

func apply_data(d: Dictionary) -> void:
	if d.get("class_id") is String and FrontierClasses.DATA.has(d.class_id): class_id = d.class_id
	super.apply_data(d)
	var p := Vector2(float(d.get("x",13)),float(d.get("y",49)))
	if is_finite(p.x) and is_finite(p.y) and p.x>=2 and p.y>=2 and p.x<=61 and p.y<=61 and FrontierMap.obstruction(Vector2i(roundi(p.x),roundi(p.y))).is_empty():
		position = p
	else: position = FrontierMap.SPAWN
	mana = clampf(float(d.get("mana",max_mana())),0,max_mana()) if d.get("mana",0) is float or d.get("mana",0) is int else max_mana()
	bandit_kills = clampi(int(d.get("bandit_kills",0)),0,1000000) if d.get("bandit_kills",0) is float or d.get("bandit_kills",0) is int else 0
	discovered.assign(["haven"])
	if d.get("discovered") is Array:
		for zone in FrontierMap.ZONES:
			if zone.id in d.discovered and zone.id not in discovered: discovered.append(zone.id)
	rewarded.clear()
	if d.get("rewarded") is Array:
		for n in d.rewarded:
			if (n is int or n is float) and int(n)>=0 and int(n)<7 and int(n) not in rewarded: rewarded.append(int(n))

func save_game() -> bool:
	var f := FileAccess.open(RPG_SAVE+".tmp",FileAccess.WRITE)
	if f==null: return false
	f.store_string(JSON.stringify(data()))
	f.flush()
	var error := f.get_error()
	f.close()
	return error==OK and DirAccess.rename_absolute(RPG_SAVE+".tmp",RPG_SAVE)==OK

func load_game() -> bool:
	if not FileAccess.file_exists(RPG_SAVE): return false
	var d: Variant = JSON.parse_string(FileAccess.get_file_as_string(RPG_SAVE))
	if not d is Dictionary: return false
	apply_data(d)
	return true
