extends SceneTree
func _initialize() -> void:
	call_deferred("capture")
func capture() -> void:
	var game: Node = load("res://scripts/frontier3d.gd").new()
	root.add_child(game)
	game.state = FrontierState.new()
	game.hud.close_modal()
	game.hud.toast_left = 0
	game.sound_on = false
	for i in 8: await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/aetheria-3d-world.png")
	game.hud.show_modal("classes")
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/aetheria-3d-classes.png")
	game.hud.show_modal("map")
	await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png("/tmp/aetheria-3d-map.png")
	print("3D_RENDER_OK")
	game.queue_free()
	await process_frame
	quit()
