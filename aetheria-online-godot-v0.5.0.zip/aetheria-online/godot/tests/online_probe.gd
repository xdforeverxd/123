extends SceneTree
var session: Node
var elapsed := 0.0
var saw_two := false
var attack_clock := 0.0
var finishing := false
func _initialize() -> void:
	_start.call_deferred()
func _start() -> void:
	var arena := Node.new()
	arena.name = "OnlineArena"
	root.add_child(arena)
	session = load("res://online/session.gd").new()
	session.name = "Session"
	arena.add_child(session)
	session.credential_file = OS.get_environment("ONLINE_TEST_IDENTITY")
	session.join_server("127.0.0.1")
func _process(delta: float) -> bool:
	if finishing: return false
	elapsed += delta
	attack_clock += delta
	if not session.snapshot.is_empty():
		var players: Dictionary = session.snapshot.players
		if OS.get_environment("ONLINE_TEST_RESTORE") == "1":
			if players.has(multiplayer_id()):
				var p: Dictionary = players[multiplayer_id()]
				if p.gold >= 10 and p.y > 0.1:
					print("ONLINE_RESTORE_PASS saved position and reward")
					_finish(0)
				else:
					printerr("Restore mismatch: ", p)
					_finish(1)
			return false
		if elapsed < 0.3: session.move.rpc_id(1, Vector2(1, 1))
		else: session.move.rpc_id(1, Vector2.ZERO)
		if players.size() >= 2: saw_two = true
		if saw_two and players.has(multiplayer_id()) and players[multiplayer_id()].gold >= 10:
			print("ONLINE_PROBE_PASS two peers, shared kill, server reward")
			_finish(0)
			return false
		if attack_clock >= 0.55:
			attack_clock = 0
			session.attack.rpc_id(1)
	if elapsed > 12:
		printerr("ONLINE_PROBE_FAIL ", session.snapshot)
		_finish(1)
	return false
func multiplayer_id() -> int:
	return session.multiplayer.get_unique_id()

func _finish(code: int) -> void:
	finishing = true
	# Let ENet finish its disconnect handshake before destroying the process.
	session.leave_server()
	await create_timer(0.3).timeout
	quit(code)
