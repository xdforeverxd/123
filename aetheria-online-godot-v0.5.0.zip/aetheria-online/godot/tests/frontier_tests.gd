extends SceneTree
var passed := 0
var failed := 0
func _initialize() -> void: call_deferred("run")
func check(ok: bool, title: String) -> void:
	if ok:
		passed += 1
		print("PASS: "+title)
	else:
		failed += 1
		push_error("FAIL: "+title)
func run() -> void:
	var map := FrontierMap.new()
	check(map.can_stand(FrontierMap.SPAWN),"safe spawn is walkable")
	check(not map.walkable(Vector2(8,46)),"buildings block movement")
	check(not map.walkable(Vector2(11,29)),"water blocks movement")
	check(not map.walkable(Vector2(-1,0)),"world edge blocks movement")
	for zone in FrontierMap.ZONES:
		var route := map.route(FrontierMap.SPAWN,zone.point)
		check(not route.is_empty(),"village connects to "+zone.name)
		var valid := true
		for p in route: valid = valid and map.can_stand(Vector2(p))
		check(valid,"route avoids obstacles: "+zone.name)
	var crosses_bridge := false
	for p in map.route(FrontierMap.SPAWN,Vector2(47,38)):
		if FrontierMap.terrain(p)=="bridge": crosses_bridge = true
	check(crosses_bridge,"eastern route crosses the designed bridge")
	var health: Array[float] = []
	for id in FrontierClasses.DATA:
		var state := FrontierState.new()
		state.class_id = id
		health.append(state.max_hp())
		check(state.max_mana()>60 and state.definition().range>0,"class has complete combat definition: "+id)
	check(health[0]>health[2],"guardian survives more damage than mage")
	var state := FrontierState.new()
	state.class_id = "mage"
	state.mana = 101
	state.position = Vector2(47,38)
	state.discovered.assign(["haven","mine"])
	state.bandit_kills = 3
	state.rewarded.assign([5,6])
	var restored := FrontierState.new()
	restored.apply_data(state.data())
	check(restored.class_id=="mage" and restored.mana==101,"class and full mana restore correctly")
	check(restored.position==state.position and "mine" in restored.discovered,"new map positions and discoveries persist")
	check(restored.rewarded==[5,6],"all seven quest reward IDs can persist")
	check(state.save_game() and restored.load_game(),"3D native save round trip")
	state = FrontierState.new()
	check(not state.claim(5),"incomplete bandit objective cannot be rewarded")
	state.bandit_kills = 3
	check(state.claim(5) and not state.claim(5) and state.gold==30,"bandit reward granted once")
	var game: Node = load("res://scripts/frontier3d.gd").new()
	root.add_child(game)
	await process_frame
	game.set_process(false)
	game.sound_on = false
	game.hud.close_modal()
	game.state = FrontierState.new()
	game.clock = 100
	check(game is Node3D and game.camera is Camera3D,"new client is a native 3D scene")
	check(game.enemies.size()==12,"forest, mine and ruin encounters initialized")
	var all_resources_reachable := true
	for r in game.resources: all_resources_reachable = all_resources_reachable and not map.route(FrontierMap.SPAWN,r.position).is_empty()
	check(all_resources_reachable,"all harvest nodes are reachable")
	var starter_routes := map.route(FrontierMap.SPAWN,Vector2(47,38))
	var p := FrontierMap.SPAWN
	var steps := 0
	while not starter_routes.is_empty() and steps<3000:
		var difference := Vector2(starter_routes[0])-p
		if difference.length()<0.16: starter_routes.pop_front()
		else: p = game.move_actor(p,difference.normalized()*0.14)
		steps += 1
	check(starter_routes.is_empty() and p.distance_to(Vector2(47,38))<0.5,"actual movement traverses bridge and reaches mine without getting stuck")
	game.state.position = FrontierMap.NPC
	game.action("interact")
	check(game.state.visited,"Mira starts quest progression")
	game.state.position = game.resources[0].position
	game.action("interact")
	check(game.state.wood==1 and game.state.gathered==1,"3D resource interaction grants materials")
	game.state.position = FrontierMap.SPAWN
	game.last_combat = -100
	game.choose_class("ranger")
	check(game.state.class_id=="ranger" and game.state.hp==115,"safe-zone class selection sets class stats")
	game.state.position = Vector2(30,38)
	game.choose_class("mage")
	check(game.state.class_id=="ranger","class switching outside safe zone is rejected")
	for e in game.enemies:
		e.hp = 0
		e.respawn = 9999
	var enemy: Dictionary = game.enemies[0]
	enemy.hp = 1000
	enemy.max_hp = 1000
	enemy.position = game.state.position+Vector2(6,0)
	game.selected = 0
	game.action("attack")
	check(enemy.hp==1000-game.state.attack_damage(),"ranger attacks at six cells range")
	var hp: float = enemy.hp
	game.action("attack")
	check(enemy.hp==hp,"primary attack cooldown prevents repeat damage")
	game.cooldowns.spin = 0
	game.action("spin")
	check(enemy.hp<hp and enemy.slow>0,"ranger special damages and slows target")
	game.state.class_id = "guardian"
	game.state.mana = 75
	game.cooldowns.attack = 0
	hp = enemy.hp
	game.action("attack")
	check(enemy.hp==hp,"guardian cannot attack beyond melee range")
	enemy.position = game.state.position+Vector2(1,0)
	game.cooldowns.spin = 0
	game.action("spin")
	check(enemy.hp<hp and enemy.slow>0,"guardian special hits nearby enemy")
	game.state.class_id = "mage"
	game.state.mana = 125
	game.cooldowns.spin = 0
	hp = enemy.hp
	game.action("spin")
	check(enemy.hp<hp and game.state.mana==99,"mage area special consumes class mana")
	game.state.class_id = "cleric"
	game.state.hp = 25
	game.state.mana = 135
	game.cooldowns.spin = 0
	game.action("spin")
	check(game.state.hp==80 and game.state.mana==111,"cleric special heals and consumes mana")
	game.cooldowns.heal = 0
	game.action("heal")
	check(game.state.hp==125 and game.state.mana==91,"shared heal respects class health cap")
	game.cooldowns.dash = 0
	game.action("dash")
	check(game.dash_left>0 and game.cooldowns.dash>0,"3D dodge activates")
	game.hud.show_modal("map")
	var t: float = game.clock
	game._process(0.05)
	check(game.clock==t,"world map pauses combat")
	game.hud.close_modal()
	for dimensions in [Vector2i(852,393),Vector2i(640,360),Vector2i(568,320)]:
		root.size = dimensions
		await process_frame
		await process_frame
		var bounds := Rect2(Vector2.ZERO,game.hud.size)
		var fit := true
		for b in game.hud.skill_buttons.values(): fit = fit and bounds.encloses(b.get_rect())
		check(fit,"3D action HUD fits %s" % dimensions)
		for mode in ["classes","map","inventory"]:
			game.hud.show_modal(mode)
			check(bounds.encloses(game.hud.modal.get_child(1).get_global_rect()),"%s fits %s" % [mode,dimensions])
			game.hud.close_modal()
	game.queue_free()
	await process_frame
	print("RESULT: %d passed, %d failed" % [passed,failed])
	quit(1 if failed else 0)
