extends SceneTree
func _initialize() -> void:
	capture.call_deferred()
func capture() -> void:
	var scene: PackedScene = load("res://online/arena.tscn")
	var game := scene.instantiate()
	root.add_child(game)
	await create_timer(1.0).timeout
	if "--connect" in OS.get_cmdline_user_args():
		assert(not game.session.snapshot.is_empty(), "3D client never received server state")
		assert(game.stage.actors.size() == 1)
		game._attack()
		await create_timer(0.12).timeout
	await RenderingServer.frame_post_draw
	var path := "/tmp/aetheria-online3d.png"
	root.get_texture().get_image().save_png(path)
	assert(game.stage.enemy.get_meta("animation") != null)
	assert(game.stage.enemy.get_meta("animation").has_animation("Running_A"))
	print("ONLINE_3D_RENDER_PASS ", path)
	game.session.leave_server()
	await create_timer(0.3).timeout
	quit()
