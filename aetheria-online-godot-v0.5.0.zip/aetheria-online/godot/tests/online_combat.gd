extends SceneTree
func _initialize() -> void:
	var session = load("res://online/session.gd").new()
	# No live server or disk writes: exercise authoritative combat steps.
	session.players = {2: {"x": 3.0, "y": 0.0, "health": 100, "revive_in": 0.0, "gold": 0}, 3: {"x": -6.0, "y": 0.0, "health": 100, "revive_in": 0.0, "gold": 0}}
	session.inputs = {2: Vector2.ONE, 3: Vector2.ZERO}
	session._tick_combat(0.01)
	assert(session.players[2].health == 80 and session.players[3].health == 100)
	session._tick_combat(0.01)
	assert(session.players[2].health == 80, "Enemy ignored its cooldown")
	for i in range(4): session._tick_combat(1.0)
	assert(session.players[2].health == 0 and session.inputs[2] == Vector2.ZERO)
	session._tick_combat(2.0)
	assert(session.players[2].health == 0, "Revived too early")
	session._tick_combat(1.0)
	assert(session.players[2].health == 100 and session.players[2].x == -6)
	session.enemy_hp = 0
	session.players[2].x = 3.0
	session._tick_combat(1.0)
	assert(session.players[2].health == 100, "Dead enemy dealt damage")
	session.enemy_hp = 120
	session.enemy_position = Vector2(3, 0)
	session.players[2].x = 0.0
	session._tick_combat(0.25)
	assert(session.enemy_position.x < 3.0 and session.enemy_mode == "chase", "Enemy did not pursue")
	var position_before_return: Vector2 = session.enemy_position
	session.players[2].x = -6.0
	session.enemy_hp = 60
	session._tick_combat(0.1)
	assert(session.enemy_position.x > position_before_return.x and session.enemy_mode == "return", "Enemy did not return")
	session._tick_combat(1.0)
	assert(session.enemy_position == Vector2(3, 0) and session.enemy_hp == 120 and session.enemy_mode == "idle")
	assert(session.players[2].health == 100 and session.players[3].health == 100, "Spawn was attacked")
	session.free()
	print("ONLINE_COMBAT_PASS range, cooldown, death, revive, chase, return, safe spawn")
	quit()
