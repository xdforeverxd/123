extends SceneTree
func _initialize() -> void:
	var session = load("res://online/session.gd").new()
	session.save_directory = OS.get_environment("ONLINE_SAVE_DIRECTORY")
	var identity := "store-test".sha256_text()
	session.identities[2] = identity
	session.players[2] = {"x": 2.5, "y": -1.25, "gold": 30}
	session._save_character(2)
	var restored: Dictionary = session._load_character(identity)
	assert(restored.gold == 30 and restored.x == 2.5 and restored.y == -1.25)
	var path: String = session.save_directory.path_join(identity + ".json")
	var file := FileAccess.open(path, FileAccess.WRITE)
	file.store_string("broken save")
	file.close()
	assert(session._load_character(identity).is_empty())
	assert(FileAccess.get_file_as_string(path) == "broken save")
	session.free()
	print("ONLINE_STORE_PASS atomic round trip and corrupt save refusal")
	quit()
