# KayKit assets

Author: Kay Lousberg, https://kaylousberg.com
License: CC0 1.0. Original license notices are included alongside this document.
Only the public free packs are used, no paid EXTRA content.

- Adventurers: https://github.com/KayKit-Game-Assets/KayKit-Character-Pack-Adventures-1.0/tree/672074b73ba276876a19e8816ecdc5241817ab47
- Medieval Hexagon: https://github.com/KayKit-Game-Assets/KayKit-Medieval-Hexagon-Pack-1.0/tree/84fa4e91af6a88989be7c99e0891cede11f2ca38

Selected glTF/GLB files and their referenced textures/buffers are preserved.
`manifest.json` records copied source files and SHA256 hashes. Godot may extract
embedded textures on import; those derived files inherit the pack license.
Characters use the included Idle, Running_A, Death_A_Pose and unarmed melee
animations. Buildings and trees are visual decoration outside player bounds.
