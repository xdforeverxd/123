extends Node3D
const ASSETS := "res://assets/kaykit/"
var session: Node
var actors: Dictionary = {}
var enemy: Node3D
var preview: Node3D

func _ready() -> void:
	var environment := WorldEnvironment.new()
	var settings := Environment.new()
	settings.background_mode = Environment.BG_COLOR
	settings.background_color = Color("9db7bd")
	settings.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	settings.ambient_light_color = Color("dbe4ee")
	settings.ambient_light_energy = 0.65
	environment.environment = settings
	add_child(environment)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -35, 0)
	sun.light_energy = 1.25
	add_child(sun)
	var camera := Camera3D.new()
	add_child(camera)
	camera.position = Vector3(0, 18, 20)
	camera.look_at(Vector3.ZERO)
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 22
	camera.current = true
	_box(Vector3(0, -0.18, 0), Vector3(34, 0.3, 25), Color("54765b"))
	_box(Vector3(-5, -0.015, 0), Vector3(16, 0.03, 2.8), Color("b6a17a"))
	_box(Vector3(3, 0.005, 0), Vector3(9, 0.04, 9), Color("7e8b62"))
	# Decorations stay outside server movement bounds, so there are no false walls.
	_building("building_home_A_blue", Vector3(-12, 0, -6), 3.0)
	_building("building_tavern_blue", Vector3(-12, 0, 4), 3.0)
	_building("building_well_blue", Vector3(-7, 0, -9), 1.8)
	for at in [Vector3(-15, 0, -8), Vector3(-15, 0, 7), Vector3(14, 0, -7), Vector3(14, 0, 6), Vector3(3, 0, 10), Vector3(10, 0, 10)]:
		var tree: Node3D = load(ASSETS + "medieval/Assets/gltf/decoration/nature/tree_single_A.gltf").instantiate()
		add_child(tree)
		tree.position = at
		tree.scale = Vector3.ONE * 3.5
	for x in range(-9, 12, 3):
		_box(Vector3(x, 0.25, -8), Vector3(0.2, 0.5, 0.2), Color("776046"))
	_label(self, "ŞAFAK KÖYÜ", Vector3(-9, 3.3, -5), Color("fff0b5"))
	_label(self, "EĞİTİM ALANI", Vector3(5, 0.3, -6), Color("eee7d2"))
	_label(self, "Güvenli doğuş", Vector3(-6, 0.2, 1.5), Color("d2f0d0"))
	enemy = _actor("Barbarian", "Haydut", Color("ffb5a4"))
	enemy.position = Vector3(3, 0, 0)
	preview = _actor("Knight", "Bağlanarak oyuna gir", Color("f4d896"))
	preview.position = Vector3(-6, 0, 0)

func _box(at: Vector3, dimensions: Vector3, color: Color) -> void:
	var node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	node.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	node.material_override = material
	node.position = at
	add_child(node)

func _building(model: String, at: Vector3, size: float) -> void:
	var scene: PackedScene = load(ASSETS + "medieval/Assets/gltf/buildings/blue/" + model + ".gltf")
	var node := scene.instantiate() as Node3D
	add_child(node)
	node.position = at
	node.scale = Vector3.ONE * size

func _label(parent: Node3D, text: String, at: Vector3, color: Color) -> Label3D:
	var label := Label3D.new()
	label.text = text
	label.position = at
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.font_size = 36
	label.pixel_size = 0.009
	label.modulate = color
	parent.add_child(label)
	return label

func _actor(model: String, title: String, color: Color) -> Node3D:
	var actor := Node3D.new()
	add_child(actor)
	var scene: PackedScene = load(ASSETS + "adventurers/Characters/gltf/" + model + ".glb")
	var body := scene.instantiate() as Node3D
	actor.add_child(body)
	var animation := body.find_child("AnimationPlayer", true, false) as AnimationPlayer
	actor.set_meta("body", body)
	actor.set_meta("animation", animation)
	actor.set_meta("caption", _label(actor, title, Vector3(0, 2.8, 0), color))
	actor.set_meta("sequence", 0)
	actor.set_meta("swing", 0.0)
	_animate(actor, "Idle")
	return actor

func _animate(actor: Node3D, animation_name: String) -> void:
	var player: AnimationPlayer = actor.get_meta("animation")
	if player == null or not player.has_animation(animation_name): return
	if animation_name in ["Idle", "Running_A", "Death_A_Pose"]:
		player.get_animation(animation_name).loop_mode = Animation.LOOP_LINEAR
	if player.current_animation != animation_name: player.play(animation_name, 0.12)

func _update_actor(actor: Node3D, at: Vector2, health: int, sequence: int, delta: float) -> void:
	var target := Vector3(at.x, 0, at.y)
	var direction := target - actor.position
	var moving := direction.length() > 0.06
	actor.position = actor.position.lerp(target, minf(1, delta * 14))
	var body: Node3D = actor.get_meta("body")
	if moving: body.rotation.y = atan2(direction.x, direction.z)
	if sequence != actor.get_meta("sequence"):
		actor.set_meta("sequence", sequence)
		actor.set_meta("swing", 0.4)
	var swing: float = maxf(0, float(actor.get_meta("swing")) - delta)
	actor.set_meta("swing", swing)
	var animation_name := "Idle"
	if health <= 0: animation_name = "Death_A_Pose"
	elif swing > 0: animation_name = "Unarmed_Melee_Attack_Punch_A"
	elif moving: animation_name = "Running_A"
	_animate(actor, animation_name)

func _process(delta: float) -> void:
	var data: Dictionary = session.snapshot
	preview.visible = data.is_empty()
	if data.is_empty():
		for actor in actors.values(): actor.queue_free()
		actors.clear()
		enemy.visible = true
		return
	var players: Dictionary = data.players
	for id in actors.keys():
		if not players.has(id):
			actors[id].queue_free()
			actors.erase(id)
	for id in players:
		var p: Dictionary = players[id]
		if not actors.has(id):
			actors[id] = _actor("Knight", "Oyuncu", Color("a6d1ff"))
			actors[id].position = Vector3(p.x, 0, p.y)
		_update_actor(actors[id], Vector2(p.x, p.y), p.health, p.get("attack_seq", 0), delta)
		var caption: Label3D = actors[id].get_meta("caption")
		caption.text = ("Sen" if id == multiplayer.get_unique_id() else "Maceracı") + " · %d / 100" % p.health
	var hp: int = data.enemy_hp
	_update_actor(enemy, data.enemy_position, hp, data.get("enemy_attack_seq", 0), delta)
	var caption: Label3D = enemy.get_meta("caption")
	caption.text = "Haydut · %d / 120" % hp if hp > 0 else "Haydut yenildi"
