extends Node
# This node must have the same path on dedicated server and clients.
const PORT := 24567
const SPEED := 5.0
var save_directory := "user://online-characters"
var credential_file := "user://online-identity.json"
var identities: Dictionary = {}
var credential := ""
var client_active := false
var save_clock := 0.0
var players: Dictionary = {}
var inputs: Dictionary = {}
var cooldowns: Dictionary = {}
const MAX_HEALTH := 100
const REVIVE_SECONDS := 3.0
const ENEMY_HOME := Vector2(3, 0)
const ENEMY_SPEED := 1.8
const ENEMY_TERRITORY := 6.0
var enemy_mode := "idle"
var enemy_attack_clock := 0.0
var enemy_attack_seq := 0
var input_age: Dictionary = {}
var enemy_hp := 120
var enemy_position := Vector2(3, 0)
var respawn := 0.0
var snapshot: Dictionary = {}
var status := "Bağlı değil"
var clock := 0.0

func host(port: int = PORT) -> Error:
	if not OS.get_environment("ONLINE_SAVE_DIRECTORY").is_empty():
		save_directory = OS.get_environment("ONLINE_SAVE_DIRECTORY")
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_server(port, 20)
	if error != OK: return error
	# Clients talk only to the authority; peer-to-peer relay is unnecessary.
	multiplayer.server_relay = false
	multiplayer.multiplayer_peer = peer
	multiplayer.peer_disconnected.connect(_left)
	status = "Sunucu hazır"
	return OK

func join_server(address: String, port: int = PORT) -> Error:
	credential = _client_credential(address, port)
	if credential.is_empty(): return ERR_FILE_CANT_READ
	var peer := ENetMultiplayerPeer.new()
	var error := peer.create_client(address, port)
	if error != OK: return error
	multiplayer.multiplayer_peer = peer
	multiplayer.connected_to_server.connect(func(): client_active = true; status = "Bağlandı"; register.rpc_id(1, credential))
	multiplayer.connection_failed.connect(func(): client_active = false; status = "Bağlantı kurulamadı")
	multiplayer.server_disconnected.connect(func(): client_active = false; status = "Sunucu bağlantısı kesildi"; snapshot = {})
	status = "Bağlanıyor…"
	return OK

func leave_server() -> void:
	client_active = false
	var peer := multiplayer.multiplayer_peer
	if peer is ENetMultiplayerPeer and peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED and not multiplayer.is_server():
		peer.disconnect_peer(1)
	snapshot = {}
	status = "Bağlantı kapatıldı"

@rpc("any_peer", "call_remote", "reliable")
func register(token: String) -> void:
	if not multiplayer.is_server(): return
	var id := multiplayer.get_remote_sender_id()
	if players.has(id): return
	if token.length() != 64 or not token.is_valid_hex_number(false):
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	var identity := token.sha256_text()
	if identity in identities.values():
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	identities[id] = identity
	players[id] = _load_character(identity)
	if players[id].is_empty():
		players.erase(id)
		identities.erase(id)
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	players[id]["attack_seq"] = 0
	players[id]["health"] = MAX_HEALTH
	players[id]["revive_in"] = 0.0
	inputs[id] = Vector2.ZERO
	input_age[id] = 0.0
	cooldowns[id] = 0.0

@rpc("any_peer", "call_remote", "unreliable_ordered", 1)
func move(direction: Vector2) -> void:
	if not multiplayer.is_server() or not direction.is_finite(): return
	var id := multiplayer.get_remote_sender_id()
	if players.has(id) and players[id].health > 0:
		inputs[id] = direction.limit_length(1.0)
		input_age[id] = 0.0

@rpc("any_peer", "call_remote", "reliable")
func attack() -> void:
	if not multiplayer.is_server(): return
	var id := multiplayer.get_remote_sender_id()
	if not players.has(id) or players[id].health <= 0 or cooldowns[id] > 0 or enemy_hp <= 0: return
	var p: Dictionary = players[id]
	if Vector2(p.x, p.y).distance_to(enemy_position) > 3.0: return
	players[id].attack_seq += 1
	cooldowns[id] = 0.5
	enemy_hp = maxi(0, enemy_hp - 20)
	if enemy_hp == 0:
		respawn = 5.0
		for other in players.values():
			if other.health > 0 and Vector2(other.x, other.y).distance_to(enemy_position) <= 8.0: other.gold += 10
		_save_all()

@rpc("authority", "call_remote", "unreliable_ordered", 2)
func receive_state(data: Dictionary) -> void:
	snapshot = data

func _left(id: int) -> void:
	if players.has(id): _save_character(id)
	identities.erase(id)
	players.erase(id)
	input_age.erase(id)
	inputs.erase(id)
	cooldowns.erase(id)

func _physics_process(delta: float) -> void:
	if not (multiplayer.multiplayer_peer is ENetMultiplayerPeer): return
	if multiplayer.multiplayer_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED: return
	if not multiplayer.is_server(): return
	save_clock += delta
	if save_clock >= 2.0:
		save_clock = 0
		_save_all()
	for id in players:
		input_age[id] += delta
		if input_age[id] > 0.3: inputs[id] = Vector2.ZERO
		var direction: Vector2 = inputs[id]
		players[id].x = clampf(players[id].x + direction.x * SPEED * delta, -10, 10)
		players[id].y = clampf(players[id].y + direction.y * SPEED * delta, -7, 7)
		cooldowns[id] = maxf(0, cooldowns[id] - delta)
	_tick_combat(delta)
	if enemy_hp == 0:
		respawn -= delta
		if respawn <= 0:
			enemy_hp = 120
			enemy_position = ENEMY_HOME
			enemy_attack_clock = 0
			enemy_mode = "idle"
	clock += delta
	if clock >= 0.05:
		clock = 0
		for peer_id in multiplayer.get_peers():
			var peer: ENetPacketPeer = multiplayer.multiplayer_peer.get_peer(peer_id)
			if peer != null and peer.get_state() == ENetPacketPeer.STATE_CONNECTED:
				receive_state.rpc_id(peer_id, {"players": players, "enemy_hp": enemy_hp, "enemy_position": enemy_position, "enemy_mode": enemy_mode, "enemy_attack_seq": enemy_attack_seq})

# Prototype persistence: one atomic JSON file per opaque, server-local identity.
# The bearer credential stays on the client; snapshots never include it.
func _client_credential(address: String, port: int) -> String:
	var records: Dictionary = {}
	if FileAccess.file_exists(credential_file):
		var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(credential_file))
		if parsed is Dictionary: records = parsed
		else: return ""
	var key := "%s:%d" % [address, port]
	if not records.has(key):
		records[key] = Crypto.new().generate_random_bytes(32).hex_encode()
		if not _atomic_json(credential_file, records):
			push_error("Client identity could not be saved")
			return ""
	var value := str(records[key])
	if value.length() != 64 or not value.is_valid_hex_number(false): return ""
	return value

func _load_character(identity: String) -> Dictionary:
	var path := save_directory.path_join(identity + ".json")
	if FileAccess.file_exists(path):
		var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
		if data is Dictionary and data.get("version") == 1:
			var x: Variant = data.get("x")
			var y: Variant = data.get("y")
			var gold: Variant = data.get("gold")
			if (x is float or x is int) and (y is float or y is int) and (gold is float or gold is int):
				if is_finite(float(x)) and is_finite(float(y)) and is_finite(float(gold)) and gold >= 0 and gold <= 1000000000:
					return {"x": clampf(x, -10, 10), "y": clampf(y, -7, 7), "gold": int(gold)}
		push_error("Invalid character save; refusing to overwrite: " + identity)
		return {}
	return {"x": 0.0, "y": 0.0, "gold": 0}

func _save_character(id: int) -> void:
	var player: Dictionary = players[id]
	var data := {"x": player.x, "y": player.y, "gold": player.gold}
	data["version"] = 1
	if not _atomic_json(save_directory.path_join(identities[id] + ".json"), data):
		push_error("Character save failed")

func _save_all() -> void:
	for id in players: _save_character(id)

func _atomic_json(path: String, data: Dictionary) -> bool:
	var absolute := ProjectSettings.globalize_path(path)
	if DirAccess.make_dir_recursive_absolute(absolute.get_base_dir()) != OK: return false
	var file := FileAccess.open(absolute + ".tmp", FileAccess.WRITE)
	if file == null: return false
	file.store_string(JSON.stringify(data))
	file.flush()
	var error := file.get_error()
	file.close()
	if error != OK: return false
	return DirAccess.rename_absolute(absolute + ".tmp", absolute) == OK

# The enemy chooses one nearest living target, at most once per second.
func _tick_combat(delta: float) -> void:
	for id in players:
		var p: Dictionary = players[id]
		if p.health <= 0:
			p.revive_in = maxf(0, p.revive_in - delta)
			inputs[id] = Vector2.ZERO
			if p.revive_in <= 0:
				p.health = MAX_HEALTH
				p.x = -6.0
				p.y = 0.0
				if identities.has(id): _save_character(id)
	enemy_attack_clock = maxf(0, enemy_attack_clock - delta)
	if enemy_hp <= 0:
		enemy_mode = "dead"
		return
	var target := -1
	var nearest := INF
	for id in players:
		var p: Dictionary = players[id]
		if p.health <= 0: continue
		if Vector2(p.x, p.y).distance_to(ENEMY_HOME) > ENEMY_TERRITORY: continue
		var distance := Vector2(p.x, p.y).distance_to(enemy_position)
		if distance < nearest:
			nearest = distance
			target = id
	if target == -1:
		enemy_position = enemy_position.move_toward(ENEMY_HOME, ENEMY_SPEED * delta)
		enemy_mode = "idle" if enemy_position.is_equal_approx(ENEMY_HOME) else "return"
		if enemy_mode == "idle": enemy_hp = 120
		return
	var target_position := Vector2(players[target].x, players[target].y)
	if nearest > 1.4:
		enemy_position = enemy_position.move_toward(target_position, minf(ENEMY_SPEED * delta, nearest - 1.4))
		enemy_mode = "chase"
	else:
		enemy_mode = "attack"
	if enemy_position.distance_to(target_position) > 2.5 or enemy_attack_clock > 0: return
	enemy_attack_seq += 1
	enemy_attack_clock = 1.0
	players[target].health = maxi(0, players[target].health - 20)
	if players[target].health == 0:
		players[target].revive_in = REVIVE_SECONDS
		inputs[target] = Vector2.ZERO
