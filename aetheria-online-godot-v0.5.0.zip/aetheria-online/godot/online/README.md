# Çevrim içi ilk teknik dilim

v0.5.0 ana sahnesi, CC0 KayKit karakterleri ve küçük bir 3D köy ile çevrim içi savaş döngüsünü gösterir. Önceki tek oyunculu sahneler dosyalarda korunur. Kaynak ve lisanslar `assets/kaykit/SOURCES.md` içindedir.

Godot 4.6 ile depo kökünden:

```sh
godot --headless --path godot res://online/arena.tscn -- --server
godot --path godot res://online/arena.tscn
```

İki istemci açın, sunucunun IP adresini yazıp Bağlan'a basın. Yerel bilgisayarda 127.0.0.1 kullanılır. Telefonda bu adres telefonun kendisidir; sunucunun LAN IP adresi gerekir. ENet UDP 24567 kullanır. Bu aşama internete yayımlanmış değildir.

Sol tarafta parmak sürükleme veya WASD hareket ettirir; SALDIR veya boşluk saldırır. Düşman 120 cana sahiptir, yakında her saldırı 20 hasar verir, sunucu 0.5 saniye bekleme uygular. Düşman ölünce yakındaki oyuncular 10 altın alır ve 5 saniye sonra yeniden doğar. Sunucu hareket hızını, sınırları, menzili ve ödülü belirler; istemci hasar/altın göndermez. En fazla 20 bağlantı yapılandırılmıştır; kapasite testi yapılmadı.

`tests/online_probe.gd` iki ayrı istemci süreciyle ortak düşman ölümünü ve iki oyuncunun ödülünü kontrol eder. Sunucu çalışırken iki probe eşzamanlı başlatılmalıdır. Bu test gerçek Android cihaz veya internet gecikme testi değildir.

Henüz hesap, tam kimlik doğrulama, PostgreSQL, envanter, gelişmiş düşman yapay zekâsı, sınıflar, otomatik yeniden bağlanma akışı ve genel internet servisi yoktur. Konum ve altın sunucuda iki saniyede bir, ödülde ve bağlantı kapanırken atomik JSON dosyasına kaydedilir. Ani kapanışta son iki saniyelik hareket kaybolabilir; disk arızasına karşı yedekleme henüz yoktur. Her cihaz sunucu adresi başına rastgele bir erişim anahtarı saklar; bu anahtar silinirse veya sunucu adresi değiştirilirse eski karakter otomatik bulunmaz. Anahtar başka cihaza aktarılırsa karaktere erişim de aktarılır. Bu prototip internet üzerinde güvenli hesap girişi yerine geçmez. Kimlik doğrulama ve istek sınırları eklenmeden herkese açık üretim sunucusu olarak kullanılmamalıdır.

Sonraki teslim: gerçek Android cihaz performans denemesi ve kontrollü uzak sunucu testi; ardından görev, envanter ve sınıf sistemleri.


Sunucu kayıt dizini varsayılan olarak Godot `user://online-characters` konumudur. `ONLINE_SAVE_DIRECTORY` ile değiştirilebilir. Bozuk karakter kaydı otomatik sıfırlanmaz, o karakterin bağlantısı reddedilir ve dosya korunur. İstemci kimliği `user://online-identity.json` dosyasındadır; anahtarlar snapshot mesajlarına eklenmez.

Tek komutla kayıt ve ağ testleri:

```sh
python3 scripts/test-online.py
```

Gerekirse `GODOT` ortam değişkenini Godot çalıştırılabilir dosyasına ayarlayın. Test geçici dizinde iki istemci çalıştırır; ödül sonrası sunucuyu yeniden başlatır ve iki karakterin konum/altınını kontrol eder. Aynı zamanda bozuk kaydın korunmasını doğrular. Kalıcılık şu an tek sunuculu prototip içindir; çok sunuculu kullanımda PostgreSQL ve işlem yönetimi gerekir.


Savaş döngüsü: oyuncu 100 canla girer. Düşman, başlangıç noktasının 6 birim çevresindeki en yakın canlı oyuncuyu saniyede 1.8 birim hızla takip eder. 2.5 birim menzil içinde saniyede en fazla bir kez 20 hasar verir; yaklaşmayı 1.4 birimde durdurur. Canı biten oyuncu hareket edemez, saldıramaz ve öldürme ödülü alamaz; üç saniye sonra güvenli (-6, 0) konumunda tam canla doğar. Can çubuğu ve yeniden doğma sayacı istemcide sunucu verisinden çizilir. Gelen hareket komutu 0.3 saniyeden eskiyse hareket durur. Hedef bölgeden çıkınca düşman başlangıç yerine döner, oraya ulaştığında canı yenilenir. Güvenli doğuş noktası takip bölgesinin dışındadır. Bu açık test alanında engel ve yol bulma henüz yoktur; duvarlı haritada navigasyon eklenmelidir.

Can ve yeniden doğma sayacı geçici oturum verisidir; yeniden giriş tam canla başlar. Kalıcı konum ve altın korunur. Bu nedenle bağlantıyı keserek savaştan kaçmayı önleyen sistem henüz yoktur. Savaş testleri menzil, saldırı aralığı, ölüm, bekleyerek yeniden doğma ve ölü düşmanın hasar verememesini kontrol eder.

Düşmanın konumu ve davranış durumu sunucu snapshot mesajında gönderilir; istemci düşman konumunu hesaplamaz. Takip, geri dönüş ve güvenli doğuş savaş testlerinde doğrulanır.

Bağlan düğmesi bağlantı sırasında Ayrıl olarak görünür. Kontrollü ayrılma ENet kapanışını başlatır; test istemcileri süreçlerini sonlandırmadan önce kapanış için süre tanır. Sunucuda istemciler arası paket aktarma kapalıdır; tüm oyun mesajları istemci ile sunucu arasındadır. Entegrasyon testi istemci ve sunucu çıktısındaki motor hatalarını da başarısız sayar. Ani ağ kesintileri ve Android uygulamasının zorla kapatılması ayrıca cihaz testinde doğrulanmalıdır.


## Android 0.5.0

Proje ana sahnesi `online/arena.tscn` olarak ayarlanmıştır. Yatay ekran, arm64-v8a ve x86_64, Android 7/API24 veya üzeri. İnternet ve ağ durumu izinleri açıktır. APK debug anahtarıyla imzalanır. Fiziksel Android cihazda test edilmedi.

Sunucuya bağlanılmadan köy ve karakterler yalnızca görsel önizleme olarak görünür; hareket ve saldırı bağlantıdan sonra çalışır. `127.0.0.1` telefonda telefonun kendisidir. Bilgisayarda sunucuyu çalıştırın, aynı yerel ağdaki telefonlara bilgisayarın LAN IP adresini yazın ve UDP24567 erişimine izin verin. Herkese açık sunucu sağlanmamaktadır.

Animasyonlar sunucunun konum, can ve saldırı sıra sayacından seçilir; hareket yumuşatılır. Aynı karakter modeli tüm oyuncular için kullanılır; görünüş seçimi ve sınıflar henüz eklenmedi. Dekorasyonlar hareket sınırlarının dışında yer alır; dünya henüz genel navigasyon/çarpışma sistemi içermeyen küçük bir test alanıdır.

Grafikli bağlantı testi (Linux X ekranı gerekir): `DISPLAY=:99 python3 scripts/test-online-visual.py`. Bu test gerçek yerel sunucuya bağlanan 3D istemciyi çizer, snapshot ve karakter oluşumunu doğrular, `/tmp/aetheria-online3d.png` görüntüsünü kaydeder ve kontrollü ayrılır.
