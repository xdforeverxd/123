extends Node2D
var session: Node
var address: LineEdit
var label: Label
var attack_button: Button
var connect_button: Button
var stage: Node3D
var stick := Vector2.ZERO
var stick_finger := -1
var stick_origin := Vector2.ZERO

func _ready() -> void:
	session = load("res://online/session.gd").new()
	session.name = "Session"
	add_child(session)
	var args := OS.get_cmdline_user_args()
	if "--server" in args:
		var error: Error = session.host()
		print("ONLINE_SERVER ", error)
		if error != OK: get_tree().quit(1)
		return
	stage = load("res://online/stage.gd").new()
	stage.session = session
	add_child(stage)
	address = LineEdit.new()
	address.position = Vector2(20, 20)
	address.size = Vector2(280, 45)
	address.text = "127.0.0.1"
	add_child(address)
	connect_button = Button.new()
	connect_button.text = "Bağlan"
	connect_button.position = Vector2(310, 20)
	connect_button.size = Vector2(120, 45)
	connect_button.pressed.connect(func():
		if multiplayer.multiplayer_peer is ENetMultiplayerPeer and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
			session.leave_server()
			return
		if not (multiplayer.multiplayer_peer is ENetMultiplayerPeer) or multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_DISCONNECTED:
			var error: Error = session.join_server(address.text.strip_edges())
			if error != OK: session.status = "Bağlantı hatası: %s" % error
	)
	add_child(connect_button)
	label = Label.new()
	label.position = Vector2(20, 78)
	add_child(label)
	attack_button = Button.new()
	attack_button.text = "SALDIR"
	attack_button.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	attack_button.position = get_viewport_rect().size - Vector2(160, 100)
	attack_button.size = Vector2(140, 80)
	attack_button.pressed.connect(_attack)
	add_child(attack_button)
	if "--connect" in args: session.join_server("127.0.0.1")

func _attack() -> void:
	if session.client_active and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
		session.attack.rpc_id(1)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and event.position.x < get_viewport_rect().size.x * 0.45 and event.position.y > 130 and stick_finger == -1:
			stick_finger = event.index
			stick_origin = event.position
		elif not event.pressed and event.index == stick_finger:
			stick_finger = -1
			stick = Vector2.ZERO
	if event is InputEventScreenDrag and event.index == stick_finger:
		stick = ((event.position - stick_origin) / 60.0).limit_length(1)
	if event is InputEventKey and event.pressed and event.keycode == KEY_SPACE: _attack()

func _process(_delta: float) -> void:
	if label == null: return
	connect_button.text = "Ayrıl" if multiplayer.multiplayer_peer is ENetMultiplayerPeer and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED else "Bağlan"
	var direction := Vector2(float(Input.is_physical_key_pressed(KEY_D)) - float(Input.is_physical_key_pressed(KEY_A)), float(Input.is_physical_key_pressed(KEY_S)) - float(Input.is_physical_key_pressed(KEY_W)))
	if stick != Vector2.ZERO: direction = stick
	if session.client_active and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED:
		session.move.rpc_id(1, direction.limit_length(1))
	label.text = session.status + " | Sol alanda sürükle / WASD · Saldır / Boşluk"
	var me: Dictionary = session.snapshot.get("players", {}).get(multiplayer.get_unique_id(), {}) if session.client_active and multiplayer.multiplayer_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTED else {}
	attack_button.disabled = me.is_empty() or me.get("health", 0) <= 0
	if not me.is_empty():
		label.text += "\nCan: %d / 100 · Altın: %d" % [me.health, me.gold]
		if me.health <= 0: label.text += " · Yeniden doğuş: %d sn" % ceili(me.revive_in)
	queue_redraw()

func _draw() -> void:
	if stage != null:
		if stick_finger >= 0:
			draw_arc(stick_origin, 60, 0, TAU, 32, Color.WHITE)
			draw_circle(stick_origin + stick * 60, 16, Color("e2c27a"))
		return
	var center := get_viewport_rect().size / 2
	draw_rect(Rect2(center - Vector2(300, 210), Vector2(600, 420)), Color("243e35"))
	var data: Dictionary = session.snapshot if session != null else {}
	if data.is_empty(): return
	var hp: int = data.enemy_hp
	var enemy_point: Vector2 = center + data.get("enemy_position", Vector2(3, 0)) * 30
	draw_circle(center + Vector2(-180, 0), 35, Color("426754"))
	draw_string(ThemeDB.fallback_font, center + Vector2(-215, 50), "Güvenli doğuş")
	if hp > 0:
		draw_circle(enemy_point, 20, Color("b94e43"))
		draw_string(ThemeDB.fallback_font, enemy_point + Vector2(-30, -30), "Düşman %d" % hp)
	for id in data.players:
		var p: Dictionary = data.players[id]
		var point := center + Vector2(p.x, p.y) * 30
		draw_circle(point, 14, Color("e2c27a") if id == multiplayer.get_unique_id() else Color("70aede"))
		draw_string(ThemeDB.fallback_font, point + Vector2(-20, -24), "%s · %d altın" % [id, p.gold])
		draw_rect(Rect2(point + Vector2(-20, 20), Vector2(40, 5)), Color("702e2e"))
		draw_rect(Rect2(point + Vector2(-20, 20), Vector2(40 * p.health / 100.0, 5)), Color("78c178"))
	if stick_finger >= 0:
		draw_arc(stick_origin, 60, 0, TAU, 32, Color.WHITE)
		draw_circle(stick_origin + stick * 60, 16, Color("e2c27a"))
